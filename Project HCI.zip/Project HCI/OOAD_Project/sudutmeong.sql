-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2020 at 07:22 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sudutmeong`
--
CREATE DATABASE IF NOT EXISTS `sudutmeong` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `sudutmeong`;

-- --------------------------------------------------------

--
-- Table structure for table `cartitem`
--

CREATE TABLE `cartitem` (
  `productID` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employeeID` int(11) NOT NULL,
  `roleID` int(11) DEFAULT NULL,
  `employeeName` varchar(150) DEFAULT NULL,
  `employeeUsername` varchar(150) DEFAULT NULL,
  `employeeDOB` date DEFAULT NULL,
  `employeeSalary` int(11) DEFAULT NULL,
  `employeeStatus` varchar(150) DEFAULT NULL,
  `employeePassword` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employeeID`, `roleID`, `employeeName`, `employeeUsername`, `employeeDOB`, `employeeSalary`, `employeeStatus`, `employeePassword`) VALUES
(1, 2, 'Calvin Surya', 'root', '2000-06-24', 10000000, 'Active', 'root'),
(2, 2, 'LOL', 'aeron', '3896-07-21', 2000000, 'Fired', 'aeron'),
(3, 1, 'a', 'as', '1999-03-05', 22222, 'Active', 'as'),
(4, 3, 'a', 's', '2000-07-24', 2, 'Fired', 's'),
(5, 4, 'Kagamine Rin', 'rin', '2000-06-14', 4000000, 'Active', 'rin'),
(6, 2, 'a', 'lol', '1998-05-07', 12, 'Fired', 'lol'),
(7, 2, 'a', 'a2', '1995-05-06', 2222, 'Fired', 'a2'),
(8, 3, 'Hatsune Miku', 'miku', '1997-04-05', 2000000, 'Active', 'miku'),
(9, 1, 'Makiru', 'makiru', '2000-06-24', 2000000, 'Active', 'makiru'),
(10, 5, 'Hatsune Miku', 'micu', '1995-05-06', 2000000, 'Active', 'miku'),
(11, 4, 'testingdoang', 'mas', '2000-06-05', 1200000, 'Active', 'mas'),
(12, 3, 'aaaa', 'tests', '2014-07-07', 123123, 'Active', 'tests');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productID` int(11) NOT NULL,
  `productName` varchar(150) DEFAULT NULL,
  `productDescription` varchar(1500) DEFAULT NULL,
  `productPrice` int(11) DEFAULT NULL,
  `productStock` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productID`, `productName`, `productDescription`, `productPrice`, `productStock`) VALUES
(1, 'berubah', 'lalala', 200000, 14),
(2, 'Bead Chain', 'Restore Full HP to All Party', 900000, 9806),
(3, 'Soma', 'Restore Full HP and MP and Restore Status Ailments to All Party', 2500000, 4691);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `roleID` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`roleID`, `name`) VALUES
(1, 'Manager'),
(2, 'Human Resource Management'),
(3, 'Storage Management'),
(4, 'Promo Management'),
(5, 'Transaction Management');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transactionID` int(11) NOT NULL,
  `purchaseDate` date DEFAULT NULL,
  `voucherID` int(11) DEFAULT NULL,
  `employeeID` int(11) DEFAULT NULL,
  `paymentType` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transactionID`, `purchaseDate`, `voucherID`, `employeeID`, `paymentType`) VALUES
(1, '2020-06-12', 1, 10, 'Cash'),
(2, '2020-06-12', NULL, 10, 'Credit');

-- --------------------------------------------------------

--
-- Table structure for table `transactiondetail`
--

CREATE TABLE `transactiondetail` (
  `transactionID` int(11) DEFAULT NULL,
  `productID` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transactiondetail`
--

INSERT INTO `transactiondetail` (`transactionID`, `productID`, `quantity`) VALUES
(1, 3, 2),
(2, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `voucher`
--

CREATE TABLE `voucher` (
  `voucherID` int(11) NOT NULL,
  `voucherDiscount` float DEFAULT NULL,
  `voucherValidDate` date DEFAULT NULL,
  `voucherStatus` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `voucher`
--

INSERT INTO `voucher` (`voucherID`, `voucherDiscount`, `voucherValidDate`, `voucherStatus`) VALUES
(1, 24.3, '2022-07-20', 'Used'),
(2, 99.9, '2025-06-07', 'Deleted');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cartitem`
--
ALTER TABLE `cartitem`
  ADD KEY `productID` (`productID`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employeeID`),
  ADD KEY `roleID` (`roleID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productID`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`roleID`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transactionID`),
  ADD KEY `voucherID` (`voucherID`),
  ADD KEY `employeeID` (`employeeID`);

--
-- Indexes for table `transactiondetail`
--
ALTER TABLE `transactiondetail`
  ADD KEY `transactionID` (`transactionID`),
  ADD KEY `productID` (`productID`);

--
-- Indexes for table `voucher`
--
ALTER TABLE `voucher`
  ADD PRIMARY KEY (`voucherID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cartitem`
--
ALTER TABLE `cartitem`
  ADD CONSTRAINT `cartitem_ibfk_1` FOREIGN KEY (`productID`) REFERENCES `product` (`productID`);

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`roleID`) REFERENCES `role` (`roleID`);

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`voucherID`) REFERENCES `voucher` (`voucherID`),
  ADD CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`employeeID`) REFERENCES `employee` (`employeeID`);

--
-- Constraints for table `transactiondetail`
--
ALTER TABLE `transactiondetail`
  ADD CONSTRAINT `transactiondetail_ibfk_1` FOREIGN KEY (`transactionID`) REFERENCES `transaction` (`transactionID`),
  ADD CONSTRAINT `transactiondetail_ibfk_2` FOREIGN KEY (`productID`) REFERENCES `product` (`productID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
