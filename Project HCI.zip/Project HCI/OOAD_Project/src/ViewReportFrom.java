import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class ViewReportFrom {
	private TransactionHandler th = new TransactionHandler();
	private int kabisat = 0;
	private int kabisat2 = 0;
	private int selectedYear = -1;
	private int selectedMonth = -1;
	private int selectedDay = -1;
	private int selectedYear2 = -1;
	private int selectedMonth2 = -1;
	private int selectedDay2 = -1;
	private int lol = 0;
	private Date before;
	private Date after;
	Vector<String>year = new Vector<String>();
	Vector<String>month = new Vector<String>();
	Vector<String>day = new Vector<String>();
	private void addYear() {
		year.removeAllElements();
		Date date = new Date(System.currentTimeMillis());
		int year = date.getYear()+1900;
		for(int i = 0;i<100;i++) {
			this.year.add(Integer.toString(year-i));
		}
	}
	private void setDay(String day) {
		selectedDay = Integer.parseInt(day);
	}
	private void addDay() {
		day.removeAllElements();
		for(int i = 1;i<=31;i++) {
			day.add(Integer.toString(i));
		}
	}
	private void addMonth() {
		month.removeAllElements();
		month.add("January");
		month.add("February");
		month.add("March");
		month.add("April");
		month.add("May");
		month.add("June");
		month.add("July");
		month.add("August");
		month.add("September");
		month.add("October");
		month.add("November");
		month.add("December");
	}
	private void validateYear(String year) {
		int tYear = Integer.parseInt(year);
		if(tYear % 4 == 0) {
			if(tYear % 10 == 0 && tYear % 40 != 0) {
				
			}
			else if(tYear % 10 == 0 && tYear % 40 == 0) {
				kabisat = 1;
			}
		}
		selectedYear = tYear;
	}
	private void validateYear2(String year) {
		int tYear = Integer.parseInt(year);
		if(tYear % 4 == 0) {
			if(tYear % 10 == 0 && tYear % 40 != 0) {
				
			}
			else if(tYear % 10 == 0 && tYear % 40 == 0) {
				kabisat2 = 1;
			}
		}
		selectedYear2 = tYear;
	}
	private void addMonth2(int index) {
		selectedMonth = index+1; 
	}
	private void addMonth3(int index) {
		selectedMonth2 = index+1; 
	}
	private void setDay2(String day) {
		selectedDay2 = Integer.parseInt(day);
	}
	private void printDetails(Transaction t) {
		JFrame frame2 = new JFrame();
		ProductHandler ph = new ProductHandler();
		ArrayList<TransactionItem> itemList = t.getTransactionItemList();
		
		ArrayList<Product> productListwithID = new ArrayList<Product>();
		productListwithID.removeAll(productListwithID);
		for(int i = 0; i<itemList.size();i++) {
			productListwithID.add(ph.getProduct(itemList.get(i).getProductID()));
		}
		JPanel panelLihat = new JPanel(new GridLayout(productListwithID.size(),0));
		panelLihat.setBorder(new EmptyBorder(10,10,10,10));
		frame2.setSize(400,400);
		for(int i = 0;i<itemList.size();i++) {
			String name;
			JPanel item = new JPanel(new GridLayout(4,1));
			item.setBorder(BorderFactory.createLineBorder(Color.BLACK));
			JLabel productID = new JLabel("Product ID: ");
			JLabel productID2 = new JLabel(Integer.toString(itemList.get(i).getProductID()));
			JLabel productName2 = new JLabel(productListwithID.get(i).getProductName());
			JLabel productName = new JLabel("Product Name: ");
			JLabel quantity = new JLabel("Quantity");
			JLabel quantity2 = new JLabel(Integer.toString(itemList.get(i).getQuantity()));
			item.add(productID);
			item.add(productID2);
			item.add(productName);
			item.add(productName2);
			item.add(quantity);
			item.add(quantity2);
			panelLihat.add(item);
		}
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				frame2.dispose();
			}
		});
		JScrollPane jsp = new JScrollPane();
		jsp.setSize(400,400);
		jsp.setViewportView(panelLihat);
		frame2.add(back,BorderLayout.NORTH);
		frame2.add(jsp,BorderLayout.CENTER);
		frame2.setSize(500,500);
		frame2.show();
	}
	private void viewTransactionMenu(Date before, Date after) {
		JFrame frameLihat = new JFrame();
		frameLihat.setSize(500,500);
		ArrayList<Transaction> listData = th.listTransaction(after, before);
		for(int i = 0;i<listData.size();i++) {
			System.out.println(listData.get(i).getTransactionID());
		}
		JPanel panelLihat = new JPanel(new GridLayout(listData.size(),1));
		JButton[] buttonList = new JButton[listData.size()];
		panelLihat.setBorder(new EmptyBorder(10,10,10,10));
		for(int i = 0;i<listData.size();i++) {
			int total = 5;
			if(listData.get(i).getVoucherID() == 0) {
				total = 4;
			}
			else {
				total = 5;
			}
			JPanel tran = new JPanel(new GridLayout(total,1));
			tran.setBorder(BorderFactory.createLineBorder(Color.BLACK));
			JLabel id = new JLabel("Transaction ID: ");
			JLabel id2 = new JLabel(Integer.toString(listData.get(i).getTransactionID()));
			tran.add(id);
			tran.add(id2);
			JLabel purchaseDate = new JLabel("Purchase Date: ");
			JLabel purchaseDate2 = new JLabel(listData.get(i).getTransactionDate().toString());
			tran.add(purchaseDate);
			tran.add(purchaseDate2);
			if(total != 4) {
				JLabel voucher = new JLabel("Voucher ID: ");
				JLabel voucher2 = new JLabel(Integer.toString(listData.get(i).getVoucherID()));
				tran.add(voucher);
				tran.add(voucher2);
			}
			JLabel employee = new JLabel("Employee ID: ");
			JLabel employee2 = new JLabel(Integer.toString(listData.get(i).getEmployeeID()));
			tran.add(employee);
			tran.add(employee2);
			JLabel paymentType = new JLabel("Payment Type: ");
			JLabel paymentType2 = new JLabel(listData.get(i).getPaymentType());
			tran.add(paymentType);
			tran.add(paymentType2);
			panelLihat.add(tran);
			buttonList[i] = new JButton("Details");
			buttonList[i].setActionCommand(Integer.toString(i));
			buttonList[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					int x = Integer.parseInt(e.getActionCommand());
					printDetails(listData.get(x));
				}
			});
			panelLihat.add(buttonList[i]);
			}
			JScrollPane jsp = new JScrollPane();
			jsp.setSize(400,400);
			jsp.setViewportView(panelLihat);
			frameLihat.add(new JLabel("View Transaction List"),BorderLayout.NORTH);
			frameLihat.add(jsp,BorderLayout.CENTER);
			frameLihat.show();
		}
	public void menu() {
		JFrame jf = new JFrame();
		jf.setSize(400,400);
		JPanel jp = new JPanel(new BorderLayout());
		JPanel input = new JPanel(new GridLayout(1, 7));
		input.setBorder(new EmptyBorder(10,10,10,10));
		addYear();
		addMonth();
		addDay();
		JComboBox<String> year = new JComboBox<String>(this.year);
		year.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				validateYear((String)year.getSelectedItem());
			}
		});
		JComboBox<String> month = new JComboBox<String>(this.month);
		month.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				addMonth2(month.getSelectedIndex());
				
			}
		});
		JComboBox<String> day = new JComboBox<String>(this.day);
		day.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setDay((String)day.getSelectedItem());
			}
		});
		
		
		JComboBox<String> year2 = new JComboBox<String>(this.year);
		year2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				validateYear2((String)year2.getSelectedItem());
			}
		});
		JComboBox<String> month2 = new JComboBox<String>(this.month);
		month.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				addMonth3(month2.getSelectedIndex());
				
			}
		});
		JComboBox<String> day2 = new JComboBox<String>(this.day);
		day.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setDay2((String)day2.getSelectedItem());
			}
		});
		JLabel tulisan2 = new JLabel("Date Range: ");
		JLabel tulisan = new JLabel(" - ");
		JLabel title = new JLabel("View Transaction List");
		jp.add(title,BorderLayout.NORTH);
		input.add(tulisan2);
		input.add(year);
		input.add(month);
		input.add(day);
		input.add(tulisan);
		input.add(year2);
		input.add(month2);
		input.add(day2);
		jp.add(input,BorderLayout.CENTER);
		JButton submit = new JButton("Enter");
		submit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JPanel x = new JPanel();
				x.setSize(400,400);
				int flag = 0;
				if(selectedYear == -1) {
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(x, "Year must be choosen!");
				}
				else if(selectedMonth == -1) {
					JOptionPane alert = new JOptionPane();
					System.out.println("Masuk ke 1");
					alert.showMessageDialog(x, "Month must be choosen!");
				}
				else if(selectedDay == -1){
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(x, "Day must be choosen!");
				}
				else {
					flag = 0;
					if(selectedMonth == 2 && kabisat == 1) {
						if(selectedDay > 29) {
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x, "Error! Day in Leap Year of February cannot more than 29");
							flag = 1;
						}
					}
					else if(selectedMonth == 2 && kabisat == 0) {
						if(selectedDay > 28) {
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x, "Error! Day in Non Leap Year of February cannot more than 28");
							flag = 1;
						}
					}
					else if(selectedMonth == 4 || selectedMonth == 6 || selectedMonth == 9 || selectedMonth == 11) {
						if(selectedMonth == 4) {
							if(selectedDay >= 31) {
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(x, "Error! Day in April cannot be more than 31");
								flag = 1;
							}
						}
						else if(selectedMonth == 6) {
							if(selectedDay >= 31) {
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(x, "Error! Day in June cannot be more than 31");
								flag = 1;}
						}
						else if(selectedMonth == 9) {
							if(selectedDay >= 31) {
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(x, "Error! Day in September cannot be more than 31");
								flag = 1;}
						}
						else if(selectedMonth == 11) {
							if(selectedDay >= 31) {
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(x, "Error! Day in November cannot be more than 31");
								flag = 1;}
						}
					}
					if(selectedYear2 == -1) {
						JOptionPane alert = new JOptionPane();
						alert.showMessageDialog(x, "Year must be choosen!");
					}
					else if(selectedMonth2 == -1) {
						JOptionPane alert = new JOptionPane();
						System.out.println("Masuk ke 2");
						alert.showMessageDialog(x, "Month must be choosen!");
					}
					else if(selectedDay2 == -1){
						JOptionPane alert = new JOptionPane();
						alert.showMessageDialog(x, "Day must be choosen!");
					}
					else {
						flag = 0;
						if(selectedMonth2 == 2 && kabisat2 == 1) {
							if(selectedDay2 > 29) {
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(x, "Error! Day in Leap Year of February cannot more than 29");
								flag = 1;
							}
						}
						else if(selectedMonth == 2 && kabisat2 == 0) {
							if(selectedDay2 > 28) {
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(x, "Error! Day in Non Leap Year of February cannot more than 28");
								flag = 1;
							}
						}
						else if(selectedMonth2 == 4 || selectedMonth2 == 6 || selectedMonth2 == 9 || selectedMonth2 == 11) {
							if(selectedMonth2 == 4) {
								if(selectedDay2 >= 31) {
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Error! Day in April cannot be more than 31");
									flag = 1;
								}
							}
							else if(selectedMonth2 == 6) {
								if(selectedDay2 >= 31) {
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Error! Day in June cannot be more than 31");
									flag = 1;}
							}
							else if(selectedMonth2 == 9) {
								if(selectedDay2 >= 31) {
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Error! Day in September cannot be more than 31");
									flag = 1;}
							}
							else if(selectedMonth2 == 11) {
								if(selectedDay2 >= 31) {
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Error! Day in November cannot be more than 31");
									flag = 1;
								}
							}
						}
						if(flag == 0) {
							before = new Date(selectedYear2-1900, selectedMonth2-1, selectedDay2);
							after = new Date(selectedYear-1900, selectedMonth-1, selectedDay);
							if(before.before(after)) {
								flag = 1;
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(x, "Error! Date in Before cannot be in future than Date in After");
								flag = 1;
							}
							else {
								viewTransactionMenu(after, before);
								jf.dispose();
								
							}
						}
					}
				}
			}
		});
		jp.add(submit,BorderLayout.SOUTH);
		jf.add(jp);
		jf.show();
	}
}
