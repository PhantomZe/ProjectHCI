import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ProductHandler {
	private ArrayList<Product> productList = new ArrayList<Product>();
	public ProductHandler() {
		// TODO Auto-generated constructor stub
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			Statement stmt = (Statement)connect.createStatement();
			ResultSet rs = stmt.executeQuery("select * from product");
			while(rs.next()) {
				Product product = new Product(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getInt(4), rs.getInt(5));
				productList.add(product);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public ArrayList<Product> getProductWithID(int id){
		ArrayList<Product> temp = null;
		for(int i = 0;i<productList.size();i++) {
			if(productList.get(i).getProductID() == id) {
				temp.add(productList.get(i));
			}
		}
		return temp;
	}
	public ArrayList<Product> getAllProduct(){
		return productList;
	}
	public Product getProduct(int productID) {
		for(int i = 0;i<productList.size();i++) {
			if(productID == productList.get(i).getProductID()) {
				return productList.get(i);
			}
		}
		return null;
	}
	public void insertData(Product product) {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			PreparedStatement prepared = connect.prepareStatement(" insert into product (productID, productName, productDescription, productPrice, productStock) values (?,?,?,?,?)");
			prepared.setInt(1, product.getProductID());
			prepared.setString(2, product.getProductName());
			prepared.setString(3, product.getProductDescription());
			prepared.setInt(4, product.getProductPrice());
			prepared.setInt(5, product.getProductStock());
			prepared.execute();
			connect.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void updateProduct(int id, String name, String description, int price, int stock) {
		int index = -1;
		for(int i = 0;i<productList.size();i++) {
			if(id == productList.get(i).getProductID()) {
				index = i;
				break;
			}
		}
		productList.get(index).setProductName(name);
		productList.get(index).setProductPrice(price);
		productList.get(index).setProductDescription(description);
		productList.get(index).setProductStock(stock);
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			PreparedStatement prepared = connect.prepareStatement("update product set productName = ?, productPrice = ?, productDescription = ?, productStock = ? where productID = ?");
			prepared.setString(1, name);
			prepared.setInt(2, price);
			prepared.setString(3, description);
			prepared.setInt(4, stock);
			prepared.setInt(5, id);
			prepared.execute();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public void addProduct(String name, String description, int price, int stock) {
		int productID = 1;
		for(int i = 0;i<productList.size();i++) {
			if(productList.get(i).getProductID() >= productID) {
				productID = productList.get(i).getProductID() + 1;
			}
		}
		Product product = new Product(productID, name, description, price, stock);
		insertData(product);
		productList.add(product);
	}
	public void deleteData(int productID) {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			PreparedStatement prepared = connect.prepareStatement("delete from product where productID = ?");
			prepared.setInt(1, productID);
			prepared.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void deleteProduct(int productID) {
		for(int i = 0;i<productList.size();i++) {
			if(productList.get(i).getProductID() == productID) {
				productList.remove(i);
				deleteData(productID);
				break;
			}
		}
		
	}
}
