import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class ProductView {
	private ProductHandler ph;
	public ProductView() {
		ph = new ProductHandler();
	}
	private void updateProduct() {
		JFrame jf = new JFrame();
		jf.setSize(500,500);
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		jf.add(back,BorderLayout.NORTH);
		JPanel menu_layer = new JPanel(new BorderLayout());
		JPanel input_layer = new JPanel(new GridLayout(5,1));
		JLabel productID = new JLabel("Product ID: ");
		JTextField productIDInput = new JTextField(16);
		input_layer.add(productID);
		input_layer.add(productIDInput);
		JLabel productName = new JLabel("Product Name: ");
		JTextField productNameInput = new JTextField(16);
		input_layer.add(productName);
		input_layer.add(productNameInput);
		JLabel productDescription = new JLabel("Product Description: ");
		JTextField productDescriptionInput = new JTextField(32);
		input_layer.add(productDescription);
		input_layer.add(productDescriptionInput);
		JLabel price = new JLabel("Product Price: ");
		JTextField priceInput = new JTextField(16);
		input_layer.add(price);
		input_layer.add(priceInput);
		JLabel stock = new JLabel("Product Stock: ");
		JTextField stockInput = new JTextField(16);
		input_layer.add(stock);
		input_layer.add(stockInput);
		menu_layer.add(input_layer,BorderLayout.CENTER);
		JButton submit = new JButton("Submit");
		submit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				int flag = 0;
				String name = productNameInput.getText().toString();
				String productDesc = productDescriptionInput.getText().toString();
				int price = -1;
				int stock = -1;
				int id = 0;
				try {
					id = Integer.parseInt(productIDInput.getText());
					for(int i = 0;i<ph.getAllProduct().size();i++) {
						if(id == ph.getAllProduct().get(i).getProductID()) {
							flag = 0;
							break;
						}
						else {
							flag = 1;
						}
					}
				} catch (Exception e) {
					// TODO: handle exception
					flag = 1;
					JFrame z = new JFrame();
					z.setSize(500, 500);
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(z, "Product ID Input only contains number!");
				}
				if(flag == 0) {
				if(name.isEmpty()) {
					flag = 1;
					JFrame z = new JFrame();
					z.setSize(500, 500);
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(z, "Product Name cannot be empty!");
				}
				else {
					if(productDesc.isEmpty()) {
						flag = 1;
						JFrame z = new JFrame();
						z.setSize(500, 500);
						JOptionPane alert = new JOptionPane();
						alert.showMessageDialog(z, "Product Description cannot be empty!");
					}
					else {
						try {
							price = Integer.parseInt(priceInput.getText().toString());
							if(price > 0) {
								try {
									stock = Integer.parseInt(stockInput.getText().toString());
									if(stock > 0) {
										JFrame z = new JFrame();
										z.setSize(500, 500);
										JOptionPane alert = new JOptionPane();
										alert.showMessageDialog(z, "Update Product Success!");
										ph.updateProduct(id, name, productDesc, price, stock);
										jf.dispose();
									}
									else {
										JFrame z = new JFrame();
										z.setSize(500, 500);
										JOptionPane alert = new JOptionPane();
										alert.showMessageDialog(z, "Product Stock cannot below than 0");
									}
								} catch (Exception e) {
									// TODO: handle exception
									flag = 1;
									JFrame z = new JFrame();
									z.setSize(500, 500);
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(z, "Product Stock cannot contain characters, only number allowed Integer number");
								}
							}
							else {
								flag = 1;
								JFrame z = new JFrame();
								z.setSize(500, 500);
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(z, "Price Input must bigger than 0");
							}
						} catch (Exception e) {
							// TODO: handle exception
							flag = 1;
							JFrame z = new JFrame();
							z.setSize(500, 500);
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(z, "Price Input only contains Integer Number , not characters, please check if there is any special characters in the field like (. ,)");
						}
					}
				}
			}
				else {
					flag = 1;
					JFrame z = new JFrame();
					z.setSize(500, 500);
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(z, "ID not found!");
				}
			}
		});
		jf.add(menu_layer,BorderLayout.CENTER);
		jf.add(submit,BorderLayout.SOUTH);
		jf.show();
		
	}
	private void deleteProduct() {
		JFrame jf = new JFrame();
		jf.setSize(600,600);
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		jf.add(back,BorderLayout.NORTH);
		JPanel allData = new JPanel(new GridLayout(ph.getAllProduct().size(),1));
		allData.setSize(400,400);
		JButton[] listButton = new JButton[ph.getAllProduct().size()];
		for(int i = 0;i<ph.getAllProduct().size();i++) {
			JPanel listData = new JPanel(new GridLayout(4,1));
			listData.setBorder(BorderFactory.createLineBorder(Color.BLACK));
			JLabel pId = new JLabel("Product ID: ");
			JLabel pIdInput = new JLabel(Integer.toString(ph.getAllProduct().get(i).getProductID()));
			JLabel pName = new JLabel("Product Name: ");
			JLabel pNameInput = new JLabel(ph.getAllProduct().get(i).getProductName());
			JLabel pDesc = new JLabel("Product Description: ");
			JLabel pDescInput = new JLabel(ph.getAllProduct().get(i).getProductDescription());
			JLabel pStock = new JLabel("Product Stock: ");
			JLabel pStockInput = new JLabel(Integer.toString(ph.getAllProduct().get(i).getProductStock()));
			listData.add(pId);
			listData.add(pIdInput);
			listData.add(pName);
			listData.add(pNameInput);
			listData.add(pDesc);
			listData.add(pDescInput);
			listData.add(pStock);
			listData.add(pStockInput);
			allData.add(listData);
			listButton[i] = new JButton("Delete Product");
			listButton[i].setActionCommand(Integer.toString(i));
			listButton[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					int index = Integer.parseInt(e.getActionCommand());
					JFrame jf2 = new JFrame();
					jf2.setSize(300,300);
					JLabel label = new JLabel("Are you sure you want to delete this product?");
					JPanel button = new JPanel(new GridLayout(0,2));
					JButton yes = new JButton("Yes");
					yes.setBackground(Color.RED);
					yes.addActionListener(new ActionListener() {
						
						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							ph.deleteProduct(ph.getAllProduct().get(index).getProductID());
							jf2.dispose();
							jf.dispose();
							JFrame z = new JFrame();
							z.setSize(500, 500);
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(z, "Delete Product Success \n Deleted Product is " + ph.getAllProduct().get(index).getProductName());
						}
					});
					button.add(yes);
					JButton no = new JButton("No");
					no.addActionListener(new ActionListener() {
						
						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							jf2.dispose();
						}
					});
					button.add(no);
					jf2.add(label,BorderLayout.NORTH);
					jf2.add(button,BorderLayout.CENTER);
					jf2.show();
				}
			});
			allData.add(listButton[i]);
		}
		JScrollPane jsp = new JScrollPane();
		jsp.setSize(200,200);
		jsp.setViewportView(allData);
		jf.add(jsp,BorderLayout.CENTER);
		jf.show();
	}
	private void viewAllProduct() {
		JFrame jf = new JFrame();
		jf.setSize(400,400);
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		jf.add(back,BorderLayout.NORTH);
		JPanel allData = new JPanel(new GridLayout(ph.getAllProduct().size(),0));
		for(int i = 0;i<ph.getAllProduct().size();i++) {
			JPanel listData = new JPanel(new GridLayout(4,1));
			listData.setBorder(BorderFactory.createLineBorder(Color.BLACK));
			JLabel pId = new JLabel("Product ID: ");
			JLabel pIdInput = new JLabel(Integer.toString(ph.getAllProduct().get(i).getProductID()));
			JLabel pName = new JLabel("Product Name: ");
			JLabel pNameInput = new JLabel(ph.getAllProduct().get(i).getProductName());
			JLabel pDesc = new JLabel("Product Description: ");
			JLabel pDescInput = new JLabel(ph.getAllProduct().get(i).getProductDescription());
			JLabel pStock = new JLabel("Product Stock: ");
			JLabel pStockInput = new JLabel(Integer.toString(ph.getAllProduct().get(i).getProductStock()));
			listData.add(pId);
			listData.add(pIdInput);
			listData.add(pName);
			listData.add(pNameInput);
			listData.add(pDesc);
			listData.add(pDescInput);
			listData.add(pStock);
			listData.add(pStockInput);
			allData.add(listData);
		}
		JScrollPane jsp = new JScrollPane();
		jsp.setSize(400,400);
		jsp.setViewportView(allData);
		jf.add(jsp,BorderLayout.CENTER);
		jf.show();
	}
	private void insert() {
		JFrame jf = new JFrame();
		jf.setSize(400,400);
		JPanel menu_layer = new JPanel(new BorderLayout());
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		jf.add(back,BorderLayout.NORTH);
		JPanel input_layer = new JPanel(new GridLayout(4,1));
		JLabel productName = new JLabel("Product Name: ");
		JTextField productNameInput = new JTextField(16);
		input_layer.add(productName);
		input_layer.add(productNameInput);
		JLabel productDescription = new JLabel("Product Description: ");
		JTextField productDescriptionInput = new JTextField(32);
		input_layer.add(productDescription);
		input_layer.add(productDescriptionInput);
		JLabel price = new JLabel("Product Price: ");
		JTextField priceInput = new JTextField(16);
		input_layer.add(price);
		input_layer.add(priceInput);
		JLabel stock = new JLabel("Product Stock: ");
		JTextField stockInput = new JTextField(16);
		input_layer.add(stock);
		input_layer.add(stockInput);
		menu_layer.add(input_layer,BorderLayout.CENTER);
		JButton submit = new JButton("Submit");
		submit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				int flag = 0;
				String name = productNameInput.getText().toString();
				String productDesc = productDescriptionInput.getText().toString();
				int price = -1;
				int stock = -1;
				if(name.isEmpty()) {
					flag = 1;
					JFrame z = new JFrame();
					z.setSize(500, 500);
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(z, "Product Name cannot be empty!");
				}
				else {
					if(productDesc.isEmpty()) {
						flag = 1;
						JFrame z = new JFrame();
						z.setSize(500, 500);
						JOptionPane alert = new JOptionPane();
						alert.showMessageDialog(z, "Product Description cannot be empty!");
					}
					else {
						try {
							price = Integer.parseInt(priceInput.getText().toString());
							if(price > 0) {
								try {
									stock = Integer.parseInt(stockInput.getText().toString());
									if(stock > 0) {
										JFrame z = new JFrame();
										z.setSize(500, 500);
										JOptionPane alert = new JOptionPane();
										alert.showMessageDialog(z, "Insert Product Success!");
										ph.addProduct(name, productDesc, price, stock);
										jf.dispose();
									}
									else {
										JFrame z = new JFrame();
										z.setSize(500, 500);
										JOptionPane alert = new JOptionPane();
										alert.showMessageDialog(z, "Product Stock cannot below than 0");
									}
								} catch (Exception e) {
									// TODO: handle exception
									flag = 1;
									JFrame z = new JFrame();
									z.setSize(500, 500);
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(z, "Product Stock cannot contain characters, only number allowed Integer number");
								}
							}
							else {
								flag = 1;
								JFrame z = new JFrame();
								z.setSize(500, 500);
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(z, "Price Input must bigger than 0");
							}
						} catch (Exception e) {
							// TODO: handle exception
							flag = 1;
							JFrame z = new JFrame();
							z.setSize(500, 500);
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(z, "Price Input only contains Integer Number , not characters, please check if there is any special characters in the field like (. ,)");
						}
					}
				}
			}
		});
		jf.add(menu_layer,BorderLayout.CENTER);
		jf.add(submit,BorderLayout.SOUTH);
		jf.show();
	}
	public void menu(String name) {
		JFrame jf = new JFrame();
		jf.setSize(400,400);
		JPanel menu_layer = new JPanel(new BorderLayout());
		JPanel button_layer = new JPanel(new GridLayout(5,0));
		JLabel title = new JLabel("Welcome " + name + "!");
		menu_layer.add(title,BorderLayout.NORTH);
		JButton insertButton = new JButton("Insert Product");
		insertButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert();
			}
		});
		button_layer.add(insertButton);
		JButton viewButton = new JButton("View All Product");
		viewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				viewAllProduct();
			}
		});
		button_layer.add(viewButton);
		JButton updateButton = new JButton("Update Product");
		updateButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				updateProduct();
			}
		});
		button_layer.add(updateButton);
		JButton deleteButton = new JButton("Delete Product");
		deleteButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				deleteProduct();
			}
		});
		button_layer.add(deleteButton);
		JButton logoutButton = new JButton("Logout");
		logoutButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		button_layer.add(logoutButton);
		menu_layer.add(button_layer,BorderLayout.CENTER);
		jf.add(menu_layer);
		jf.show();
	}
}
