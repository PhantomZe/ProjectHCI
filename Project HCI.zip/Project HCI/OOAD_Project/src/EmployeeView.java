import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Date;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

public class EmployeeView {
	private EmployeeHandler eh = new EmployeeHandler();
	private String roleName2="Manager";
	private int kabisat = 0;
	private int selectedYear = -1;
	private int selectedMonth = -1;
	private int selectedDay = -1;
	private int lol = 0;
	Vector<String>year = new Vector<String>();
	Vector<String>month = new Vector<String>();
	Vector<String>day = new Vector<String>();
	public EmployeeHandler getEmployeeHandler() {
		return eh;
	}
	public void updateData(){
		
	}
	private void addYear() {
		year.removeAllElements();
		Date date = new Date(System.currentTimeMillis());
		int year = date.getYear()+1900;
		for(int i = 0;i<100;i++) {
			this.year.add(Integer.toString(year-i));
		}
	}
	private void setDay(String day) {
		selectedDay = Integer.parseInt(day);
	}
	private void addDay() {
		day.removeAllElements();
		for(int i = 1;i<=31;i++) {
			day.add(Integer.toString(i));
		}
	}
	private void updateEmployee() {
		selectedDay = -1;
		selectedMonth = -1;
		selectedYear = -1;
		kabisat = 0;
		JFrame jf = new JFrame();
		JPanel jp = new JPanel(new BorderLayout());
		JPanel input = new JPanel(new GridLayout(7, 2));
		input.setBorder(new EmptyBorder(10,10,10,10));
		JLabel id = new JLabel("EmployeeID: ");
		JLabel jl = new JLabel("Update Employee");
		jp.add(jl,BorderLayout.NORTH);
		input.add(id);
		JTextField id_input = new JTextField(16);
		input.add(id_input);
		JLabel username = new JLabel("Username: ");
		input.add(username);
		JTextField username_input = new JTextField(16);
		input.add(username_input);
		JLabel password = new JLabel("Password: ");
		input.add(password);
		JPasswordField password_input = new JPasswordField(16);
		input.add(password_input);
		JLabel name = new JLabel("Name: ");
		input.add(name);
		JTextField name_input = new JTextField(16);
		input.add(name_input);
		JLabel salary = new JLabel("Salary: ");
		JTextField salary_input = new JTextField(16);
		input.add(salary);
		input.add(salary_input);
		JLabel role = new JLabel("Role: ");
		String[] listData = {"Manager","Human Resource Management","Storage Management","Promo Management","Transaction Management"};
		JComboBox<String> roleList = new JComboBox<String>(listData);
		addYear();
		addMonth();
		addDay();
		JComboBox<String> year = new JComboBox<String>(this.year);
		year.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				validateYear((String)year.getSelectedItem());
			}
		});
		JComboBox<String> month = new JComboBox<String>(this.month);
		month.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				addMonth2(month.getSelectedIndex());
				
			}
		});
		JComboBox<String> day = new JComboBox<String>(this.day);
		day.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setDay((String)day.getSelectedItem());
			}
		});
		roleList.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String roleName = (String)roleList.getSelectedItem();
				roleName2 = roleName;
			}
		});
		input.add(role);
		input.add(roleList);
		JPanel dob= new JPanel(new GridLayout(1,3));
		dob.add(year);
		dob.add(month);
		dob.add(day);
		JLabel DOB_title = new JLabel("Date of Birth");
		input.add(DOB_title);
		input.add(dob);
		JButton submit = new JButton("Submit");
		submit.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				int flag = 0;
				JFrame x = new JFrame();
				x.setSize(200,400);
				String ids = id_input.getText();
					for(int i = 0;i<ids.length();i++) {
						if(ids.charAt(i) < '0'|| ids.charAt(i) > '9') {
							flag = 1;
							break;
						}
					}
				int xe = 0;
				if(flag == 1) {
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(x, "Input of ID must be number!");
				}
				else {
					xe = Integer.parseInt(ids);
				}
				int flag2 = 1;
				for(int i = 0;i<eh.getAllEmployee().size();i++) {
					if(eh.getAllEmployee().get(i).getEmployeeID() == xe) {
						flag2 = 0;
						break;
					}
				}
				if(flag == 0 && flag2 == 1) {
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(x, "Input ID not found!");
				}
				else if(flag == 0 && flag2 == 0) {
				String usernameTemp = username_input.getText();
				ArrayList<Employee> employeeList = eh.getAllEmployee();
				for(int i = 0;i<employeeList.size();i++) {
					if(usernameTemp.equals(employeeList.get(i).getEmployeeUsername())) {
						flag = 1;
						break;
					}
					else {
						flag = 0;
					}
				}
				
				if(username_input.getText().isEmpty()) {
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(x, "Username cannot be empty!");
				}
				else if(flag == 1) {
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(x, "Username already taken! Please choose another username.");
				}
				else {
						if(password_input.getText().isEmpty()) {
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x, "Password cannot be empty!");
						}
						else {
						if(name_input.getText().isEmpty()) {
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x, "Name cannot be empty!");
						}
						else {
							flag = 0;
							String sal = salary_input.getText();
							for(int i = 0;i<sal.length();i++) {
								if(sal.charAt(i) >= '0' && sal.charAt(i) <= '9') {
									flag = 0;
								}
								else {
									flag = 1;
									break;
								}
							}
							if(salary_input.getText().isEmpty()) {
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(x, "Salary cannot be empty!");
							}
							else if(flag == 1) {
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(x, "Salary cannot contains character, only number's allowed! ");
							}
							else {
								if(selectedYear == -1) {
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Year must be choosen!");
								}
								else if(selectedMonth == -1) {
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Month must be choosen!");
								}
								else if(selectedDay == -1){
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Day must be choosen!");
								}
								else {
									flag = 0;
									if(selectedMonth == 2 && kabisat == 1) {
										if(selectedDay > 29) {
											JOptionPane alert = new JOptionPane();
											alert.showMessageDialog(x, "Error! Day in Leap Year of February cannot more than 29");
											flag = 1;
										}
									}
									else if(selectedMonth == 2 && kabisat == 0) {
										if(selectedDay > 28) {
											JOptionPane alert = new JOptionPane();
											alert.showMessageDialog(x, "Error! Day in Non Leap Year of February cannot more than 28");
											flag = 1;
										}
									}
									else if(selectedMonth == 4 || selectedMonth == 6 || selectedMonth == 9 || selectedMonth == 11) {
										if(selectedMonth == 4) {
											if(selectedDay >= 31) {
												JOptionPane alert = new JOptionPane();
												alert.showMessageDialog(x, "Error! Day in April cannot be more than 31");
												flag = 1;
											}
										}
										else if(selectedMonth == 6) {
											if(selectedDay >= 31) {
												JOptionPane alert = new JOptionPane();
												alert.showMessageDialog(x, "Error! Day in June cannot be more than 31");
												flag = 1;}
										}
										else if(selectedMonth == 9) {
											if(selectedDay >= 31) {
												JOptionPane alert = new JOptionPane();
												alert.showMessageDialog(x, "Error! Day in September cannot be more than 31");
												flag = 1;}
										}
										else if(selectedMonth == 11) {
											if(selectedDay >= 31) {
												JOptionPane alert = new JOptionPane();
												alert.showMessageDialog(x, "Error! Day in November cannot be more than 31");
												flag = 1;}
										}
									}
									if(flag == 0) {
										Date date = new Date(selectedYear-1900, selectedMonth-1, selectedDay);
										Date date2 = new Date(System.currentTimeMillis());
										if(date.after(date2) || date.equals(date2)) {
											JOptionPane alert = new JOptionPane();
											alert.showMessageDialog(x, "Date of Birth cannot be future than Current Time!");
											flag = 1;
										}
										else {
											String userName = username_input.getText();
											String namae = name_input.getText();
											String pass = password_input.getText();
											int salary2 = Integer.parseInt(salary_input.getText());
											eh.updateEmployee(Integer.parseInt(ids), namae, userName, date, salary2, roleName2, password_input.getText());
											JOptionPane alert = new JOptionPane();
											alert.showMessageDialog(x, "Update Success!");
											jf.dispose();
										}
										}
									}
								}
							}
						}
					}
				}
			}
		});
		jp.add(input,BorderLayout.CENTER);
		jp.add(submit,BorderLayout.SOUTH);
		jf.add(jp);
		jf.setSize(400,400);
		jf.show();
	}
	private void resetPass() {
		JFrame frame = new JFrame();
		JButton jb = new JButton("Back");
		jb.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				frame.dispose();
			}
		});
		frame.add(jb,BorderLayout.NORTH);
		JPanel isi = new JPanel(new BorderLayout());
		JLabel title = new JLabel("Reset Password");
		isi.add(title,BorderLayout.NORTH);
		JPanel resetPass = new JPanel(new GridLayout(2,1));
		JLabel tulisan = new JLabel("Input ID");
		resetPass.add(tulisan);
		JTextField input = new JTextField(16);
		resetPass.add(input);
		JButton submit = new JButton("Submit");
		submit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(input.getText().isEmpty()) {
					JFrame x = new JFrame();
					x.setSize(300,300);
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(x,"Please Enter the ID");
				}
				else {
					int flag = 0;
					String id = input.getText();
					for(int i = 0;i<id.length();i++) {
						if(id.charAt(i) < '0' || id.charAt(i) > '9') {
							flag = 1;
							break;
						}
					}
					if(flag == 1) {
						JFrame x = new JFrame();
						x.setSize(300,300);
						JOptionPane alert = new JOptionPane();
						alert.showMessageDialog(x,"Input must be number!");
					}
					else {
						int id2 = Integer.parseInt(id);
						for(int i = 0;i<eh.getAllEmployee().size();i++) {
							if(id2 == eh.getAllEmployee().get(i).getEmployeeID()) {
								flag = 0;
								eh.resetPassword(id2);
								JFrame x = new JFrame();
								x.setSize(300,300);
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(x,"The Password of Employee with ID " + Integer.toString(eh.getAllEmployee().get(i).getEmployeeID()) + " Changed into " + eh.getAllEmployee().get(i).getEmployeePassword());
								break;
							}
							else {
								flag = 1;
							}
						}
						if(flag == 1) {
							JFrame x = new JFrame();
							x.setSize(300,300);
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x,"Cannot find the ID!, Please check your input!");
						}
					}
				}
			}
		});
		isi.add(resetPass,BorderLayout.CENTER);
		isi.add(submit,BorderLayout.SOUTH);
		frame.add(isi,BorderLayout.CENTER);
		frame.setSize(500,500);
		frame.show();
	}
	private void addMonth() {
		month.removeAllElements();
		month.add("January");
		month.add("February");
		month.add("March");
		month.add("April");
		month.add("May");
		month.add("June");
		month.add("July");
		month.add("August");
		month.add("September");
		month.add("October");
		month.add("November");
		month.add("December");
	}
	private void validateYear(String year) {
		int tYear = Integer.parseInt(year);
		if(tYear % 4 == 0) {
			if(tYear % 10 == 0 && tYear % 40 != 0) {
				
			}
			else if(tYear % 10 == 0 && tYear % 40 == 0) {
				kabisat = 1;
			}
		}
		selectedYear = tYear;
	}
	private void addMonth2(int index) {
		selectedMonth = index+1; 
	}
	private void fire() {
		JFrame jf = new JFrame();
		jf.setSize(300,300);
		JOptionPane alert = new JOptionPane();
		alert.showMessageDialog(jf, "You click on the index " + lol);
	}
	private void fireEmployee() {
		JFrame jf = new JFrame();
		JPanel jp = new JPanel(new BorderLayout());
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		jp.add(back,BorderLayout.NORTH);
		JPanel listEmployee = new JPanel(new GridLayout(eh.getAllEmployee().size(),1));
		JButton[] listButton = new JButton[eh.getAllEmployee().size()];
		listEmployee.setBorder(new EmptyBorder(10,10,10,10));
		for(int i = 0;i<eh.getAllEmployee().size();i++) {
			if(eh.getAllEmployee().get(i).getEmployeeStatus().equalsIgnoreCase("active")) {
				JPanel employee = new JPanel(new GridLayout(8,2));
				employee.setBorder(BorderFactory.createLineBorder(Color.BLACK));
				JLabel id = new JLabel(Integer.toString(eh.getAllEmployee().get(i).getEmployeeID()));
				JLabel roleID = new JLabel(eh.getEmployeeRole(eh.getAllEmployee().get(i).getRoleID()));
				JLabel name = new JLabel(eh.getAllEmployee().get(i).getEmployeeName());
				JLabel salary = new JLabel(Integer.toString(eh.getAllEmployee().get(i).getEmployeeSalary()));
				JLabel id1 = new JLabel("ID: ");
				JLabel id2 = new JLabel("Role Name: ");
				JLabel id3 = new JLabel("Name: ");
				JLabel id6 = new JLabel("Salary: ");
				employee.add(id1);
				employee.add(id);
				employee.add(id2);
				employee.add(roleID);
				employee.add(id3);
				employee.add(name);
				employee.add(id6);
				employee.add(salary);
				listEmployee.add(employee);
				listButton[i] = new JButton("Fire Employee");
				listButton[i].setActionCommand(Integer.toString(i));
				listButton[i].addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						int x = Integer.parseInt(e.getActionCommand());
						JFrame validation = new JFrame();
						JPanel panel = new JPanel(new GridLayout(0,2));
						JLabel label = new JLabel("Are you sure you want to fire this employee?");
						validation.add(label,BorderLayout.NORTH);
						JButton button = new JButton("Yes");
						button.setBackground(Color.RED);
						JButton button2 = new JButton("No");
						panel.add(button);
						panel.add(button2);
						button.addActionListener(new ActionListener() {
							
							@Override
							public void actionPerformed(ActionEvent e) {
								// TODO Auto-generated method stub
								JFrame z = new JFrame();
								z.setSize(500, 500);
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(z, "You fired " + eh.getAllEmployee().get(x).getEmployeeName() + " !");
								eh.firedEmployee(x);
								validation.dispose();
							}
						});
						button2.addActionListener(new ActionListener() {
							
							@Override
							public void actionPerformed(ActionEvent e) {
								// TODO Auto-generated method stub
								validation.dispose();
							}
						});
						validation.setSize(300,300);
						validation.add(panel,BorderLayout.CENTER);
						validation.show();
					}
				});
				listEmployee.add(listButton[i]);
			}
		}
		JScrollPane jsp = new JScrollPane();
		jsp.setSize(400,400);
		jsp.setViewportView(listEmployee);
		jp.add(jsp,BorderLayout.CENTER);
		jf.add(jp);
		jf.setSize(500,500);
		jf.show();
		
	}
	private void viewAllEmployeeMenu() {
		JFrame jf = new JFrame();
		JPanel jp = new JPanel(new BorderLayout());
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		jp.add(back,BorderLayout.NORTH);
		JPanel listEmployee = new JPanel(new GridLayout(eh.getAllEmployee().size(),0));
		listEmployee.setBorder(new EmptyBorder(10,10,10,10));
		for(int i = 0;i<eh.getAllEmployee().size();i++) {
			if(eh.getAllEmployee().get(i).getEmployeeStatus().equalsIgnoreCase("active")) {
				JPanel employee = new JPanel(new GridLayout(8,1));
				employee.setBorder(BorderFactory.createLineBorder(Color.BLACK));
				JLabel id = new JLabel(Integer.toString(eh.getAllEmployee().get(i).getEmployeeID()));
				JLabel roleID = new JLabel(eh.getEmployeeRole(eh.getAllEmployee().get(i).getRoleID()));
				JLabel username = new JLabel(eh.getAllEmployee().get(i).getEmployeeUsername());
				JLabel name = new JLabel(eh.getAllEmployee().get(i).getEmployeeName());
				JLabel DOB = new JLabel(eh.getAllEmployee().get(i).getEmployeeDOB().toString());
				JLabel salary = new JLabel(Integer.toString(eh.getAllEmployee().get(i).getEmployeeSalary()));
				JLabel status = new JLabel(eh.getAllEmployee().get(i).getEmployeeStatus());
				JLabel pass = new JLabel(eh.getAllEmployee().get(i).getEmployeePassword());
				JLabel id1 = new JLabel("ID: ");
				JLabel id2 = new JLabel("Role Name: ");
				JLabel id3 = new JLabel("Name: ");
				JLabel id4 = new JLabel("Username: ");
				JLabel id5 = new JLabel("Password: ");
				JLabel id6 = new JLabel("Salary: ");
				JLabel id7 = new JLabel("Date of Birth: ");
				JLabel id8 = new JLabel("Status: ");
				employee.add(id1);
				employee.add(id);
				employee.add(id2);
				employee.add(roleID);
				employee.add(id3);
				employee.add(name);
				employee.add(id4);
				employee.add(username);
				employee.add(id5);
				employee.add(pass);
				employee.add(id6);
				employee.add(salary);
				employee.add(id7);
				employee.add(DOB);
				employee.add(id8);
				employee.add(status);
				listEmployee.add(employee);
			}
		}
		JScrollPane jsp = new JScrollPane();
		jsp.setSize(400,400);
		jsp.setViewportView(listEmployee);
		jp.add(jsp,BorderLayout.CENTER);
		jf.add(jp);
		jf.setSize(500,500);
		jf.show();
	}
	private void addMenu(ArrayList<Employee> employee) {
		JFrame jf = new JFrame();
		JPanel jp = new JPanel(new BorderLayout());
		JPanel input = new JPanel(new GridLayout(6, 2));
		input.setBorder(new EmptyBorder(10,10,10,10));
		JLabel jl = new JLabel("Add Employee");
		jp.add(jl,BorderLayout.NORTH);
		JLabel username = new JLabel("Username: ");
		input.add(username);
		JTextField username_input = new JTextField(16);
		input.add(username_input);
		JLabel password = new JLabel("Password: ");
		input.add(password);
		JPasswordField password_input = new JPasswordField(16);
		input.add(password_input);
		JLabel name = new JLabel("Name: ");
		input.add(name);
		JTextField name_input = new JTextField(16);
		input.add(name_input);
		JLabel salary = new JLabel("Salary: ");
		JTextField salary_input = new JTextField(16);
		input.add(salary);
		input.add(salary_input);
		JLabel role = new JLabel("Role: ");
		String[] listData = {"Manager","Human Resource Management","Storage Management","Promo Management","Transaction Management"};
		JComboBox<String> roleList = new JComboBox<String>(listData);
		addYear();
		addMonth();
		addDay();
		JComboBox<String> year = new JComboBox<String>(this.year);
		year.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				validateYear((String)year.getSelectedItem());
			}
		});
		JComboBox<String> month = new JComboBox<String>(this.month);
		month.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				addMonth2(month.getSelectedIndex());
				
			}
		});
		JComboBox<String> day = new JComboBox<String>(this.day);
		day.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setDay((String)day.getSelectedItem());
			}
		});
		roleList.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String roleName = (String)roleList.getSelectedItem();
				roleName2 = roleName;
			}
		});
		input.add(role);
		input.add(roleList);
		JPanel dob= new JPanel(new GridLayout(1,3));
		dob.add(year);
		dob.add(month);
		dob.add(day);
		JLabel DOB_title = new JLabel("Date of Birth");
		input.add(DOB_title);
		input.add(dob);
		JButton submit = new JButton("Submit");
		submit.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				JFrame x = new JFrame();
				x.setSize(200,400);
				int flag = 0;
				String usernameTemp = username_input.getText();
				ArrayList<Employee> employeeList = eh.getAllEmployee();
				for(int i = 0;i<employeeList.size();i++) {
					if(usernameTemp.equals(employeeList.get(i).getEmployeeUsername())) {
						flag = 1;
						break;
					}
					else {
						flag = 0;
					}
				}
				if(username_input.getText().isEmpty()) {
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(x, "Username cannot be empty!");
				}
				else if(flag == 1) {
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(x, "Username already taken! Please choose another username.");
				}
				else {
						if(password_input.getText().isEmpty()) {
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x, "Password cannot be empty!");
						}
						else {
						if(name_input.getText().isEmpty()) {
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x, "Name cannot be empty!");
						}
						else {
							flag = 0;
							String sal = salary_input.getText();
							for(int i = 0;i<sal.length();i++) {
								if(sal.charAt(i) >= '0' && sal.charAt(i) <= '9') {
									flag = 0;
								}
								else {
									flag = 1;
									break;
								}
							}
							if(salary_input.getText().isEmpty()) {
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(x, "Salary cannot be empty!");
							}
							else if(flag == 1) {
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(x, "Salary cannot contains character, only number's allowed! ");
							}
							else {
								if(selectedYear == -1) {
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Year must be choosen!");
								}
								else if(selectedMonth == -1) {
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Month must be choosen!");
								}
								else if(selectedDay == -1){
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Day must be choosen!");
								}
								else {
									flag = 0;
									if(selectedMonth == 2 && kabisat == 1) {
										if(selectedDay > 29) {
											JOptionPane alert = new JOptionPane();
											alert.showMessageDialog(x, "Error! Day in Leap Year of February cannot more than 29");
											flag = 1;
										}
									}
									else if(selectedMonth == 2 && kabisat == 0) {
										if(selectedDay > 28) {
											JOptionPane alert = new JOptionPane();
											alert.showMessageDialog(x, "Error! Day in Non Leap Year of February cannot more than 28");
											flag = 1;
										}
									}
									else if(selectedMonth == 4 || selectedMonth == 6 || selectedMonth == 9 || selectedMonth == 11) {
										if(selectedMonth == 4) {
											if(selectedDay >= 31) {
												JOptionPane alert = new JOptionPane();
												alert.showMessageDialog(x, "Error! Day in April cannot be more than 31");
												flag = 1;
											}
										}
										else if(selectedMonth == 6) {
											if(selectedDay >= 31) {
												JOptionPane alert = new JOptionPane();
												alert.showMessageDialog(x, "Error! Day in June cannot be more than 31");
												flag = 1;}
										}
										else if(selectedMonth == 9) {
											if(selectedDay >= 31) {
												JOptionPane alert = new JOptionPane();
												alert.showMessageDialog(x, "Error! Day in September cannot be more than 31");
												flag = 1;}
										}
										else if(selectedMonth == 11) {
											if(selectedDay >= 31) {
												JOptionPane alert = new JOptionPane();
												alert.showMessageDialog(x, "Error! Day in November cannot be more than 31");
												flag = 1;}
										}
									}
									if(flag == 0) {
										Date date = new Date(selectedYear-1900, selectedMonth-1, selectedDay);
										Date date2 = new Date(System.currentTimeMillis());
										if(date.after(date2) || date.equals(date2)) {
											JOptionPane alert = new JOptionPane();
											alert.showMessageDialog(x, "Date of Birth cannot be future than Current Time");
											flag = 1;
										}
										else {
											String userName = username_input.getText();
											String namae = name_input.getText();
											String pass = password_input.getText();
											int salary2 = Integer.parseInt(salary_input.getText());
											eh.addEmployee(namae, userName, date, salary2, roleName2, pass);
											JOptionPane alert = new JOptionPane();
											alert.showMessageDialog(x, "Insert Success!");
											jf.dispose();
										}
									}
								}
							}
						}
					}
				}
			}
		});
		jp.add(input,BorderLayout.CENTER);
		jp.add(submit,BorderLayout.SOUTH);
		jf.add(jp);
		jf.setSize(400,400);
		jf.show();
	}
	public void menu(String names, ArrayList<Employee> employee) {
		JFrame jf = new JFrame();
		JPanel choose = new JPanel(new GridLayout(6,0));
		choose.setBorder(new EmptyBorder(10,10,10,10));
		JLabel title_name = new JLabel("Welcome " + names + "!");
		JButton buttonAddEmployee = new JButton("Add Employee");
		buttonAddEmployee.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				addMenu(employee);
			}
		});
		JButton viewAllEmployee = new JButton("View All Employee");
		viewAllEmployee.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				viewAllEmployeeMenu();
			}
		});
		JButton fireEmployee = new JButton("Fire Employee");
		fireEmployee.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				fireEmployee();
			}
		});
		JButton resetPasswordEmployee = new JButton("Reset Password");
		resetPasswordEmployee.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				resetPass();
			}
		});
		JButton updateEmployee = new JButton("Update Employee Data");
		updateEmployee.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				updateEmployee();
			}
		});
		JButton logout = new JButton("Logout");
		logout.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		choose.add(buttonAddEmployee);
		choose.add(viewAllEmployee);
		choose.add(fireEmployee);
		choose.add(resetPasswordEmployee);
		choose.add(updateEmployee);
		choose.add(logout);
		jf.add(title_name,BorderLayout.NORTH);
		jf.add(choose,BorderLayout.CENTER);
		jf.setSize(500, 500);
		jf.show();
	}
}
