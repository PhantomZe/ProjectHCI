import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Transaction {
	private ArrayList<TransactionItem> transactionItemList = new ArrayList<TransactionItem>();
	private int transactionID;
	private Date transactionDate;
	private int voucherID;
	private int employeeID;
	private String paymentType;

	public Transaction(int transactionID, Date transactionDate, int voucherID, int employeeID, String paymentType) {
		// TODO Auto-generated constructor stub
		this.transactionID = transactionID;
		this.transactionDate = transactionDate;
		this.voucherID = voucherID;
		this.employeeID = employeeID;
		this.paymentType = paymentType;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong", "root", "");
			PreparedStatement stmt = (PreparedStatement) connect.prepareStatement("select * from transactiondetail where transactionID = ?");
			stmt.setInt(1, transactionID);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				TransactionItem ti = new TransactionItem(rs.getInt(1), rs.getInt(2), rs.getInt(3));
				transactionItemList.add(ti);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public TransactionItem getTransactionItems(int transactionID) {
		for(int i = 0;i<transactionItemList.size();i++) {
			if(transactionID == transactionItemList.get(i).getTransactionID()) {
				return transactionItemList.get(i);
			}
		}
		return null;
	}
	public void addTransactionItem(TransactionItem ti) {
		int tID = transactionID;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong", "root", "");
			PreparedStatement stmt = (PreparedStatement) connect.prepareStatement("insert into transactiondetail values(?,?,?)");
			stmt.setInt(1, tID);
			stmt.setInt(2, ti.getProductID());
			stmt.setInt(3, ti.getQuantity());
			stmt.execute();
			connect.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public ArrayList<TransactionItem> getTransactionItemList() {
		return transactionItemList;
	}

	public void setTransactionItemList(ArrayList<TransactionItem> transactionItemList) {
		this.transactionItemList = transactionItemList;
	}

	public int getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public int getVoucherID() {
		return voucherID;
	}

	public void setVoucherID(int voucherID) {
		this.voucherID = voucherID;
	}

	public int getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
		
}
