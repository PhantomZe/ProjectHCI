import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

public class VoucherHandler {
	private ArrayList<Voucher> voucherList = new ArrayList<Voucher>();
	
	public VoucherHandler() {
		// TODO Auto-generated constructor stub
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			Statement stmt = (Statement)connect.createStatement();
			ResultSet rs = stmt.executeQuery("select * from voucher");
			while(rs.next()) {
				int voucherID = rs.getInt(1);
				float voucherDiscount = rs.getFloat(2);
				Date voucherValidDate = rs.getDate(3);
				String voucherStatus = rs.getString(4);
				Voucher voucher = new Voucher(voucherID, voucherDiscount, voucherValidDate, voucherStatus);
				voucherList.add(voucher);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public ArrayList<Voucher> getAllVoucher(){
		return voucherList;
	}
	public void insertVoucher(float voucherDiscount, Date voucherValidDate) {
		int voucherID = 1;
		for(int i = 0;i<voucherList.size();i++) {
			if(voucherList.get(i).getVoucherID() >= voucherID) {
				voucherID = voucherList.get(i).getVoucherID() + 1;
			}
			else {
				
			}
		}
		String voucherStatus = "Active";
		Voucher voucher = new Voucher(voucherID, voucherDiscount, voucherValidDate, voucherStatus);
		voucherList.add(voucher);
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			PreparedStatement query = connect.prepareStatement("insert into voucher(voucherID,voucherDiscount,voucherValidDate,voucherStatus) values(?,?,?,?)");
			query.setInt(1, voucherID);
			query.setFloat(2, voucherDiscount);
			query.setDate(3, voucherValidDate);
			query.setString(4, voucherStatus);
			query.execute();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public void validateAllVoucher() {
		long millis = System.currentTimeMillis();
		Date date = new Date(millis);
		for(int i = 0;i<voucherList.size();i++) {
			if(voucherList.get(i).getVoucherValidDate().compareTo(date) > 0) {
				voucherList.get(i).setVoucherStatus("Expired");
			}
		}
	}
	public void updateVoucher(int voucherID, float voucherDiscount, Date voucherValidDate) {
		int index = -1;
		for(int i = 0;i<voucherList.size();i++) {
			if(voucherList.get(i).getVoucherID() == voucherID) {
				index = i;
				break;
			}
		}
		if(index != -1) {
			voucherList.get(index).updateVoucher(voucherDiscount, voucherValidDate);
			try {
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
				PreparedStatement query = connect.prepareStatement("update voucher set voucherDiscount = ?, voucherValidDate = ? where voucherID = ?");
				query.setFloat(1, voucherDiscount);
				query.setDate(2, voucherValidDate);
				query.setInt(3, voucherID);
				query.execute();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}	
	}
	public boolean deleteVoucher(int voucherID) {
		for(int i = 0;i<voucherList.size();i++) {
			if(voucherID == voucherList.get(i).getVoucherID()) {
				voucherList.remove(i);
				try {
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
					PreparedStatement query = connect.prepareStatement("update voucher set voucherStatus = ? where voucherID = ?");
					query.setString(1, "Deleted");
					query.setInt(2, voucherID);
					query.execute();
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				return true;
			}
		}
		return false;
	}
	public float useVoucher(int voucherID) {
		long millis = System.currentTimeMillis();
		for(int i = 0;i<voucherList.size();i++) {
			if(voucherList.get(i).getVoucherStatus().equals("Active")) {
				voucherList.get(i).setVoucherStatus("Used");
				try {
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
					PreparedStatement stmt = connect.prepareStatement("update voucher set voucherStatus = ? where voucherID = ?");
					String data = "Used";
					stmt.setString(1, data);
					stmt.setInt(2, voucherID);
					stmt.execute();
					connect.close();
				} catch (Exception e) {
					// TODO: handle exception
				}
				return voucherList.get(i).getVoucherDiscount();
			}
		}
		return 0;
	}
	public Voucher getVoucher(int voucherID) {
		for(int i = 0;i<voucherList.size();i++) {
			if(voucherID == voucherList.get(i).getVoucherID()) {
				return voucherList.get(i);
			}
		}
		return null;
	}
}
