import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class TransactionHandler {
	private ArrayList<Transaction> transactionList = new ArrayList<Transaction>();
	public TransactionHandler() {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			Statement stmt = (Statement)connect.createStatement();
			ResultSet rs = stmt.executeQuery("select * from transaction");
			while(rs.next()) {
				int TransactionID;
				Date date;
				int VoucherID;
				int EmployeeID;
				String paymentType;
				TransactionID = rs.getInt(1);
				date = rs.getDate(2);
				VoucherID = rs.getInt(3);
				EmployeeID = rs.getInt(4);
				paymentType = rs.getString(5);
				Transaction t = new Transaction(TransactionID, date, VoucherID, EmployeeID, paymentType);
				transactionList.add(t);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void addTransaction(Date date, int VoucherID, int EmployeeID, String paymentType,CartHandler ch) {
		int tID = 1;
		for(int i = 0;i<transactionList.size();i++) {
			if(transactionList.get(i).getTransactionID() >= 1) {
				tID = transactionList.get(i).getTransactionID() + 1;
			}
		}
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			PreparedStatement prepared = connection.prepareStatement("insert into transaction values(?,?,?,?,?)");
			prepared.setInt(1, tID);
			prepared.setDate(2, date);
			if(VoucherID == 0) {
				prepared.setNull(3, java.sql.Types.INTEGER);
			}
			else {
				prepared.setInt(3, VoucherID);
			}
			prepared.setInt(4,EmployeeID);
			prepared.setString(5, paymentType);
			prepared.execute();
			connection.close();
			Transaction t = new Transaction(tID, date, VoucherID, EmployeeID, paymentType);
			for(int i = 0;i<ch.getCartItem().size();i++){
				TransactionItem ti = new TransactionItem(tID, ch.getCartItem().get(i).getProduct().getProductID(), ch.getCartItem().get(i).getQuantity());
				t.addTransactionItem(ti);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public Transaction getTransactionAt(int index) {
		return transactionList.get(index);
	}
	public ArrayList<Transaction> listTransaction(Date before, Date after){
		ArrayList<Transaction> temp = new ArrayList<Transaction>();
		temp.removeAll(temp);
		for(int i = 0;i<transactionList.size();i++) {
			if((transactionList.get(i).getTransactionDate().before(before) || transactionList.get(i).getTransactionDate().equals(before)) && (transactionList.get(i).getTransactionDate().after(after) || transactionList.get(i).getTransactionDate().equals(after))) {
				temp.add(transactionList.get(i));
			}
		}
		return temp;
	}
}
