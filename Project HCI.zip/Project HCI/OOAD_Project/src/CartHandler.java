import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class CartHandler {
	private ArrayList<CartItem> cartList = new ArrayList<CartItem>();
	public CartHandler() {

	}
	public ArrayList<CartItem> getCartItem() {
		return cartList;
	}
	public void updateStock(int productID, int quantity) {
		ProductHandler ph = new ProductHandler();
		for(int i = 0;i<cartList.size();i++) {
			if(cartList.get(i).getProduct().getProductID() == productID) {
				cartList.get(i).setQuantity(cartList.get(i).getQuantity() + quantity);
				ph.updateProduct(ph.getProduct(productID).getProductID(), ph.getProduct(productID).getProductName(), ph.getProduct(productID).getProductDescription(), ph.getProduct(productID).getProductPrice(), ph.getProduct(productID).getProductStock()-quantity);
			}
		}
	}
	public int calculateTotalPrice(float discount) {
		int totalPrice = 0;
		for(int i = 0;i<cartList.size();i++) {
			totalPrice += (((cartList.get(i).getProduct().getProductPrice())*((100.0f-discount)/100))*((float)cartList.get(i).getQuantity()));
			System.out.println("Price : " + cartList.get(i).getProduct().getProductPrice());
		}
		return totalPrice;
	}
	public int addToCart(int productID,int quantity) {
		int index = 0;
		ProductHandler ph = new ProductHandler();
		for(int i = 0;i<cartList.size();i++) {
			if(cartList.get(i).getProduct().getProductID() == productID) {
				if(ph.getProduct(cartList.get(i).getProduct().getProductID()).getProductStock() - quantity > 0) {
					cartList.get(i).getProduct().setProductStock(cartList.get(i).getProduct().getProductStock() + quantity);
					updateStock(productID, quantity);
					index = 1;
					break;
				}
				else {
					index = 1;
					return 1;
				}
			}
		}
		if(index == 0) {
			try {
				if(ph.getProduct(productID).getProductStock() - quantity > 0) {
					CartItem cartItem = new CartItem(productID,quantity);
					cartList.add(cartItem);		
					ph.updateProduct(ph.getProduct(productID).getProductID(), ph.getProduct(productID).getProductName(), ph.getProduct(productID).getProductDescription(), ph.getProduct(productID).getProductPrice(), ph.getProduct(productID).getProductStock()-quantity);
				}
				else {
					return 2;
				}
				
			}catch (Exception e) {
				// TODO: handle exception
			}
		}
		return 0;
	}
}
