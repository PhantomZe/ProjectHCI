import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class RoleHandler{
	private ArrayList<Role> list = new ArrayList<Role>();
	public RoleHandler() {
		// TODO Auto-generated constructor stub
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			Statement stmt = (Statement)connect.createStatement();
			ResultSet rs = stmt.executeQuery("select * from role");
			while(rs.next()) {
				int x = rs.getInt(1);
				String name = rs.getString(2);
				Role role = new Role(x,name);
				list.add(role);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public ArrayList<Role> getAllRole() {
		return list;
	}
	public void addRole(Role role) {
		list.add(role);
	}
	public Role getRole(int roleID) {
		int index = -1;
		for(int i = 0;i<list.size();i++) {
			if(list.get(i).getRoleID() == roleID) {
				index = i;
				break;
			}
		}
		if(index == -1) {
			return null;
		}
		else {
			return list.get(index);
		}
	}
}
