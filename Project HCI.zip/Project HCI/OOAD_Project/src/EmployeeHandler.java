import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class EmployeeHandler {
	private ArrayList<Employee> employeeList = new ArrayList<Employee>();
	public EmployeeHandler() {
		// TODO Auto-generated constructor stub
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			Statement stmt = (Statement)connect.createStatement();
			ResultSet rs = stmt.executeQuery("select * from employee");
			while(rs.next()) {
				int EmployeeID = rs.getInt(1);
				int roleID = rs.getInt(2);
				String EmployeeName = rs.getString(3);
				String EmployeeUsername = rs.getString(4);
				Date EmployeeDOB = rs.getDate(5);
				int EmployeeSalary = rs.getInt(6);
				String status = rs.getString(7);
				String password = rs.getString(8);
				Employee em = new Employee(EmployeeID, roleID, EmployeeName, EmployeeUsername, EmployeeDOB, EmployeeSalary, status, password);
				employeeList.add(em);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public ArrayList<Employee> getAllEmployee(){
		return employeeList;
	}
	public String getEmployeeRole(int roleID) {
		RoleHandler rh = new RoleHandler();
		for(int i = 0;i<rh.getAllRole().size();i++) {
			if(roleID == rh.getAllRole().get(i).getRoleID()) {
				return rh.getAllRole().get(i).getRoleName();
			}
		}
		return null;
	}
	public void resetPassword(int employeeID) {
		int index = -1;
		for(int i = 0;i<employeeList.size();i++) {
			if(employeeList.get(i).getEmployeeID() == employeeID) {
				index = i;
				break;
			}
		}
		employeeList.get(index).setEmployeePassword("dummy");
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			PreparedStatement query = connect.prepareStatement("update employee set employeePassword = ? where employeeID = ?");
			query.setString(1, "dummy");
			query.setInt(2, employeeID);
			query.execute();
			connect.commit();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void firedEmployee(int index) {
		employeeList.get(index).setEmployeeStatus("Fired");
		int id = employeeList.get(index).getEmployeeID();
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			PreparedStatement query = connect.prepareStatement("update employee set employeeStatus = ? where employeeID = ?");
			query.setString(1, "Fired");
			query.setInt(2, id);
			query.execute();
			connect.commit();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void updateEmployee(int id, String name, String username, Date DOB, int salary, String role, String password) {
		RoleHandler rh = new RoleHandler();
		int index = -1;
		for(int i = 0;i<rh.getAllRole().size();i++) {
			if(rh.getAllRole().get(i).getRoleName().equals(role)) {
				index = i;
				break;
			}
		}
		for(int i = 0;i<employeeList.size();i++) {
			if(id == employeeList.get(i).getEmployeeID()) {
				employeeList.get(i).setEmployeeName(name);
				employeeList.get(i).setEmployeeUsername(username);
				employeeList.get(i).setEmployeeDOB(DOB);
				employeeList.get(i).setRoleID(rh.getAllRole().get(index).getRoleID());
				employeeList.get(i).setEmployeePassword(password);
				employeeList.get(i).setEmployeeSalary(salary);
				try {
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
					PreparedStatement query = connect.prepareStatement("update employee set roleID = ?,employeeName = ?,employeeUsername = ?,employeeDOB = ?,employeeSalary = ?,employeePassword = ? where employeeID = ?");
					query.setInt(1,rh.getAllRole().get(index).getRoleID());
					query.setString(2, name);
					query.setString(3, username);
					query.setDate(4,DOB);
					query.setInt(5, salary);
					query.setString(6, password);
					query.setInt(7, id);
					query.execute();
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				break;
			}
		}
	}
	public void addEmployee(String EmployeeName, String EmployeeUsername, Date EmployeeDOB, int EmployeeSalary, String role, String password) {
		int employeeID = 1;
		for(int i = 0;i<employeeList.size();i++) {
			if(employeeList.get(i).getEmployeeID() >= employeeID) {
				employeeID = employeeList.get(i).getEmployeeID() + 1;
			}
		}
		String status = "Active";
		RoleHandler rh = new RoleHandler();
		int index = -1;
		for(int i = 0;i<rh.getAllRole().size();i++) {
			if(rh.getAllRole().get(i).getRoleName().equals(role)) {
				index = i;
				break;
			}
		}
		Employee employee = new Employee(employeeID, rh.getAllRole().get(index).getRoleID(), EmployeeName, EmployeeUsername, EmployeeDOB, EmployeeSalary, status, password);
		employeeList.add(employee);
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudutmeong","root","");
			PreparedStatement query = connect.prepareStatement("insert into employee (employeeID,roleID,employeeName,employeeUsername,employeeDOB,employeeSalary,employeeStatus,employeePassword) "
																	+ " values (?,?,?,?,?,?,?,?)");
			query.setInt(1, employeeID);
			query.setInt(2, rh.getAllRole().get(index).getRoleID());
			query.setString(3, EmployeeName);
			query.setString(4, EmployeeUsername);
			query.setDate(5, EmployeeDOB);
			query.setInt(6, EmployeeSalary);
			query.setString(7, status);
			query.setString(8, password);
			query.execute();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
