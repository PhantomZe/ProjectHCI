
public class ManageVoucherForm {
	
}
