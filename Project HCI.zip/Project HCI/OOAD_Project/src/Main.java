import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
public class Main extends JFrame{
	JFrame frame = new JFrame();
	JLabel title = new JLabel("Welcome to Sudutmeong!");
	public Main() {
		EmployeeView ev = new EmployeeView();
		JPanel layout = new JPanel(new BorderLayout());
		layout.add(title,BorderLayout.NORTH);
		JPanel login = new JPanel(new BorderLayout());
		JPanel input = new JPanel(new GridLayout(3,1));
		JLabel username = new JLabel("Username: ");
		JLabel password = new JLabel("Password: ");
		JTextField username_column = new JTextField(16);
		JPasswordField password_column = new JPasswordField(16);
		input.add(username);
		input.add(username_column);
		input.add(password);
		input.add(password_column);
		login.add(input,BorderLayout.CENTER);
		JButton b = new JButton("Login");
		b.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				String username = username_column.getText().toString();
				String password = password_column.getText().toString();
				int index = -1;
				int fired = 0;
				for(int i = 0;i<ev.getEmployeeHandler().getAllEmployee().size();i++) {
					if(ev.getEmployeeHandler().getAllEmployee().get(i).getEmployeeUsername().equals(username) && ev.getEmployeeHandler().getAllEmployee().get(i).getEmployeePassword().equals(password)) {
						index = i;
						if(ev.getEmployeeHandler().getAllEmployee().get(i).getEmployeeStatus().equalsIgnoreCase("fired")) {
							fired = 1;
							index = -1;
						}
						break;
					}
				}
				if(index != -1) {
					if(ev.getEmployeeHandler().getAllEmployee().get(index).getRoleID() == 1) {
						ManagerView mv = new ManagerView();
						mv.menu(ev.getEmployeeHandler().getAllEmployee().get(index).getEmployeeName(), ev.getEmployeeHandler().getAllEmployee());
					}
					else if(ev.getEmployeeHandler().getAllEmployee().get(index).getRoleID() == 2) {
						ev.menu(ev.getEmployeeHandler().getAllEmployee().get(index).getEmployeeName(), ev.getEmployeeHandler().getAllEmployee());
					}
					else if(ev.getEmployeeHandler().getAllEmployee().get(index).getRoleID() == 3) {
						ProductView pv = new ProductView();
						pv.menu(ev.getEmployeeHandler().getAllEmployee().get(index).getEmployeeName());
					}
					else if(ev.getEmployeeHandler().getAllEmployee().get(index).getRoleID() == 4) {
						VoucherView vv = new VoucherView();
						vv.menu(ev.getEmployeeHandler().getAllEmployee().get(index).getEmployeeName());
					}
					else if(ev.getEmployeeHandler().getAllEmployee().get(index).getRoleID() == 5) {
						CashierView cv = new CashierView(ev.getEmployeeHandler().getAllEmployee().get(index).getEmployeeID());
						cv.menu(ev.getEmployeeHandler().getAllEmployee().get(index).getEmployeeID());
					}
				}
				else if(fired == 1) {
					JFrame x = new JFrame();
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(x, "You Already Fired!");
				}
				else {
					JFrame x = new JFrame();
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(x, "Username or Password is wrong!");
				}
			}
		});
		login.add(b,BorderLayout.SOUTH);
		frame.add(title,BorderLayout.NORTH);
		frame.add(login,BorderLayout.CENTER);
		frame.setSize(500,500);
		frame.show();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
