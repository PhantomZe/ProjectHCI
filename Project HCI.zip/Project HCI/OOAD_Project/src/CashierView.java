import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.colorchooser.DefaultColorSelectionModel;

public class CashierView {
	CartHandler ch = new CartHandler();
	private int voucherID = 0;
	private int cashierID = 0;
	private String paymentType = null;
	Vector<String> list = new Vector<String>();
	public void setVoucher(int voucherID) {
		this.voucherID = voucherID;
	}
	public CashierView(int cashierID) {
		this.cashierID = cashierID;
	}
	private void createTransaction() {
		TransactionHandler th = new TransactionHandler();
		Date date = new Date(System.currentTimeMillis());
		th.addTransaction(date,voucherID,cashierID,paymentType,ch);
		JFrame frame = new JFrame();
		JOptionPane panel = new JOptionPane();
		VoucherHandler vh = new VoucherHandler();
		if(voucherID != 0) {
			panel.showMessageDialog(frame, "The payment are Rp. " + ch.calculateTotalPrice(vh.getVoucher(voucherID).getVoucherDiscount()));
		}
		else {	
			panel.showMessageDialog(frame, "The payment are Rp. " + ch.calculateTotalPrice(0.f));
		}
	}
	private void setPayment(String payment) {
		paymentType = payment;
	}
	private void paymentType() {
		list.removeAllElements();
		list.add("Credit");
		list.add("Cash");
		JFrame frame = new JFrame();
		frame.setSize(200,100);
		JPanel panel = new JPanel(new GridLayout(1,1));
		JLabel label = new JLabel("Payment Type: ");
		JComboBox<String> listPayment= new JComboBox<String>(list);
		listPayment.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setPayment(listPayment.getSelectedItem().toString());
			}
		});
		panel.add(label);
		panel.add(listPayment);
		frame.add(panel,BorderLayout.CENTER);
		JButton button = new JButton("Submit");
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(paymentType.isEmpty()) {
					JFrame frame2 = new JFrame();
					JOptionPane option = new JOptionPane();
					option.showMessageDialog(frame2, "You must choose the Payment Type!");
				}
				else {
					createTransaction();
					frame.dispose();
				}
			}
		});
		frame.add(button,BorderLayout.SOUTH);
		frame.show();
	}
	private void applyVoucher() {
		JFrame frame = new JFrame();
		frame.setSize(400,400);
		VoucherHandler vh = new VoucherHandler();
		int index = 0;
		for(int i = 0;i<vh.getAllVoucher().size();i++) {
			if(vh.getAllVoucher().get(i).getVoucherStatus().equalsIgnoreCase("active")) {
				index += 1;
			}
		}
		if(index == 0) {
			JOptionPane warning = new JOptionPane();
			frame.setSize(200,200);
			warning.showMessageDialog(frame, "There is no Voucher Available");
			paymentType();
			frame.dispose();
		}
		else {
			JPanel voucher_list = new JPanel(new GridLayout(index,1));
			JButton[] button_list = new JButton[index];
			for(int i = 0;i<vh.getAllVoucher().size();i++) {
				if(vh.getAllVoucher().get(i).getVoucherStatus().equalsIgnoreCase("active")) {
					JPanel vouchers = new JPanel(new GridLayout(2,1));
					JLabel label = new JLabel("Voucher Discount: ");
					JLabel discount = new JLabel(Float.toString(vh.getAllVoucher().get(i).getVoucherDiscount()) + " %");
					JLabel validDate = new JLabel("Voucher Valid Date: ");
					JLabel vValidDate = new JLabel(vh.getAllVoucher().get(i).getVoucherValidDate().toString());
					vouchers.add(label);
					vouchers.add(discount);
					vouchers.add(validDate);
					vouchers.add(vValidDate);
					button_list[i] = new JButton("Use Voucher");
					button_list[i].setActionCommand(Integer.toString(i));
					button_list[i].addActionListener(new ActionListener() {
						
						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							int index = Integer.parseInt(e.getActionCommand());
							setVoucher(vh.getAllVoucher().get(index).getVoucherID());
							vh.useVoucher(voucherID);
							paymentType();
							frame.dispose();
						}
					});
					voucher_list.add(vouchers);
					voucher_list.add(button_list[i]);
				}
			}
			JScrollPane jsp = new JScrollPane();
			jsp.setViewportView(voucher_list);
			jsp.setSize(500,500);
			frame.add(jsp,BorderLayout.CENTER);
			frame.show();
		}
	}
	private void cartView() {
		JFrame jf = new JFrame();
		JButton buttonBack = new JButton("Back");
		buttonBack.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		jf.add(buttonBack,BorderLayout.NORTH);
		jf.setSize(500,500);
		ProductHandler ph = new ProductHandler();
		ArrayList<Product> productList = ph.getAllProduct();
		JButton buttonSubmit = new JButton("Enter");
		JPanel listBarang = new JPanel(new GridLayout(productList.size(),1));
		JButton[] buttonList = new JButton[productList.size()];
		for(int i = 0;i<productList.size();i++) {
			JPanel panelBarang = new JPanel(new GridLayout(4,1));
			panelBarang.setBorder(BorderFactory.createLineBorder(Color.BLACK));
			JLabel label = new JLabel("Product Name: ");
			JLabel name = new JLabel(productList.get(i).getProductName());
			JLabel label2 = new JLabel("Product Price: ");
			JLabel price = new JLabel(Integer.toString(productList.get(i).getProductPrice()));
			JLabel stockLabel = new JLabel("Product Stock: ");
			JLabel stock = new JLabel(Integer.toString(productList.get(i).getProductStock()));
			JLabel description = new JLabel("Product Description: ");
			JLabel desc = new JLabel(productList.get(i).getProductDescription());
			panelBarang.add(label);
			panelBarang.add(name);
			panelBarang.add(label2);
			panelBarang.add(price);
			panelBarang.add(stockLabel);
			panelBarang.add(stock);
			panelBarang.add(description);
			panelBarang.add(desc);
			listBarang.add(panelBarang);
			buttonList[i] = new JButton("Add to Cart");
			buttonList[i].setActionCommand(Integer.toString(i));
			buttonList[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					JFrame jx = new JFrame();
					jx.setSize(400,400);
					int index = Integer.parseInt(arg0.getActionCommand());
					JButton jb = new JButton("Back");
					jx.add(jb,BorderLayout.NORTH);
					JLabel tulisan = new JLabel("Input Quantity");
					JTextField input = new JTextField();
					input.setColumns(10);
					JPanel form = new JPanel(new GridLayout(2,1));
					form.add(tulisan);
					form.add(input);
					JButton submit = new JButton("Enter");
					submit.addActionListener(new ActionListener() {
						
						@Override
						public void actionPerformed(ActionEvent arg0) {
							// TODO Auto-generated method stub
							try {
								int quantity = 0;
								System.out.println(input.getText().toString());
								quantity = Integer.parseInt(input.getText().toString());
								if(productList.get(index).getProductStock() == 0) {
									JFrame a = new JFrame();
									a.setSize(200,100);
									JOptionPane warning = new JOptionPane();
									warning.showMessageDialog(a, "Stock is empty!");
								}
								else if(productList.get(index).getProductStock() - quantity < 0) {
									JFrame a = new JFrame();
									a.setSize(200,100);
									JOptionPane warning = new JOptionPane();
									warning.showMessageDialog(a, "Stock is insufficient!");
								}
								else {
									ch.addToCart(productList.get(index).getProductID(), quantity);
									System.out.println(ch.getCartItem().size());
									input.setText(null);
									jx.dispose();
								}
							} catch (Exception e) {
								// TODO: handle exception
								JFrame a = new JFrame();
								a.setSize(200,100);
								JOptionPane warning = new JOptionPane();
								warning.showMessageDialog(a, "Input must be Integer");
							}
						}
					});
					jx.add(form,BorderLayout.CENTER);
					jx.add(submit,BorderLayout.SOUTH);
					jx.setSize(400,400);
					jx.show();
				}
			});
			
			listBarang.add(buttonList[i]);
		}
		JScrollPane jsp = new JScrollPane();
		jsp.setViewportView(listBarang);
		jf.add(jsp,BorderLayout.CENTER);
		buttonSubmit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JFrame jf2 = new JFrame();
				jf2.setSize(300,300);
				JLabel text = new JLabel("Do you want to Apply Voucher too?");
				JPanel panel = new JPanel(new GridLayout(1,0));
				JButton button = new JButton("Yes");
				JButton button2 = new JButton("No");
				button.addMouseListener(new MouseListener() {
					
					@Override
					public void mouseReleased(MouseEvent arg0) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void mousePressed(MouseEvent arg0) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void mouseExited(MouseEvent arg0) {
						// TODO Auto-generated method stub
						button.setBackground(null);
					}
					
					@Override
					public void mouseEntered(MouseEvent arg0) {
						// TODO Auto-generated method stub
						button.setBackground(Color.RED);
					}
					
					@Override
					public void mouseClicked(MouseEvent arg0) {
						// TODO Auto-generated method stub
						applyVoucher();
						jf2.dispose();
					}
				});
				button2.addMouseListener(new MouseListener() {
					
					@Override
					public void mouseReleased(MouseEvent e) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void mousePressed(MouseEvent e) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void mouseExited(MouseEvent e) {
						// TODO Auto-generated method stub
						button2.setBackground(null);
					}
					
					@Override
					public void mouseEntered(MouseEvent e) {
						// TODO Auto-generated method stub
						button2.setBackground(Color.RED);
					}
					
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						paymentType();
						jf2.dispose();
					}
				});
				panel.add(button);
				panel.add(button2);
				jf2.add(text,BorderLayout.NORTH);
				jf2.add(panel,BorderLayout.CENTER);
				jf2.show();
				jf.dispose();
			}
		});
		jf.add(buttonSubmit,BorderLayout.SOUTH);
		jf.show();
	}
	public void menu(int employeeID) {
		
		JFrame jf = new JFrame();
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		jf.add(back,BorderLayout.NORTH);
		JButton button = new JButton("Add to Cart");
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cartView();
			}
		});
		jf.add(button,BorderLayout.CENTER);
		jf.setSize(500,500);
		jf.show();
	}
}
