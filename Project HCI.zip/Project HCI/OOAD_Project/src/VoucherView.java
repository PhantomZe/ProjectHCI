import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class VoucherView {
	private VoucherHandler vh;
	private int kabisat = 0;
	private int selectedYear = -1;
	private int selectedMonth = -1;
	private int selectedDay = -1;
	private Vector<String> month = new Vector<String>();
	private Vector<String> year = new Vector<String>();
	private Vector<String> day = new Vector<String>();
	private void addYear() {
		year.removeAllElements();
		int year = 2020;
		for(int i = 0;i<100;i++) {
			this.year.add(Integer.toString(year+i));
		}
	}
	private void setDay(String day) {
		selectedDay = Integer.parseInt(day);
	}
	private void addDay() {
		day.removeAllElements();
		for(int i = 1;i<=31;i++) {
			day.add(Integer.toString(i));
		}
	}
	private void addMonth() {
		month.removeAllElements();
		month.add("January");
		month.add("February");
		month.add("March");
		month.add("April");
		month.add("May");
		month.add("June");
		month.add("July");
		month.add("August");
		month.add("September");
		month.add("October");
		month.add("November");
		month.add("December");
	}
	private void validateYear(String year) {
		int tYear = Integer.parseInt(year);
		if(tYear % 4 == 0) {
			if(tYear % 10 == 0 && tYear % 40 != 0) {
				
			}
			else if(tYear % 10 == 0 && tYear % 40 == 0) {
				kabisat = 1;
			}
		}
		selectedYear = tYear;
	}
	private void addMonth2(int index) {
		selectedMonth = index+1; 
	}
	public VoucherView() {
		vh = new VoucherHandler();
	}
	public void updateVoucher() {
		selectedDay = -1;
		selectedMonth = -1;
		selectedYear = -1;
		kabisat = 0;
		JFrame jf = new JFrame();
		JPanel jp = new JPanel(new BorderLayout());
		JPanel input = new JPanel(new GridLayout(7, 2));
		input.setBorder(new EmptyBorder(10,10,10,10));
		JLabel id = new JLabel("VoucherID: ");
		JLabel jl = new JLabel("Update Employee");
		jp.add(jl,BorderLayout.NORTH);
		input.add(id);
		JTextField id_input = new JTextField(16);
		input.add(id_input);

		JLabel discount = new JLabel("Discount: ");
		JTextField discount_input = new JTextField(16);
		input.add(discount);
		input.add(discount_input);
		addYear();
		addMonth();
		addDay();
		JComboBox<String> year = new JComboBox<String>(this.year);
		year.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				validateYear((String)year.getSelectedItem());
			}
		});
		JComboBox<String> month = new JComboBox<String>(this.month);
		month.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				addMonth2(month.getSelectedIndex());
				
			}
		});
		JComboBox<String> day = new JComboBox<String>(this.day);
		day.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setDay((String)day.getSelectedItem());
			}
		});
		JPanel valid_date= new JPanel(new GridLayout(1,3));
		valid_date.add(year);
		valid_date.add(month);
		valid_date.add(day);
		JLabel valid_date_title = new JLabel("Date of Birth");
		input.add(valid_date_title);
		input.add(valid_date);
		JButton submit = new JButton("Submit");
		submit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				float discounts= 0;
				int flag = 0;
				int id = Integer.parseInt(id_input.getText().toString());
				for(int i = 0;i<vh.getAllVoucher().size();i++) {
					if(id == vh.getAllVoucher().get(i).getVoucherID()) {
						flag = 0;
						break;
					}
					else {
						flag = 1;
					}
				}
				if(flag == 0) {
				try {
					discounts = Float.parseFloat(discount_input.getText()); 
					if(discounts > 100 || discounts < 1) {
						JFrame z = new JFrame();
						z.setSize(500, 500);
						JOptionPane alert = new JOptionPane();
						alert.showMessageDialog(z, "The input only can take 1 to 100!");
						flag = 1;
					}
				} catch (Exception e2) {
					// TODO: handle exception
					flag = 1;
					JFrame z = new JFrame();
					z.setSize(500, 500);
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(z, "The discount input only can take number, it's not allowed characters in discount area!");
				}
				if(flag == 0) {
					Date dateNow = new Date(System.currentTimeMillis());
					Date dateCurr = new Date(selectedYear-1900, selectedMonth-1, selectedDay);
					JFrame x = new JFrame();
					x.setSize(500,500);
					if(dateCurr.after(dateNow)) {
						if(selectedYear == -1) {
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x, "Year must be choosen!");
						}
						else if(selectedMonth == -1) {
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x, "Month must be choosen!");
						}
						else if(selectedDay == -1){
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x, "Day must be choosen!");
						}
						else {
							flag = 0;
							if(selectedMonth == 2 && kabisat == 1) {
								if(selectedDay > 29) {
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Error! Day in Leap Year of February cannot more than 29");
									flag = 1;
								}
							}
							else if(selectedMonth == 2 && kabisat == 0) {
								if(selectedDay > 28) {
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Error! Day in Non Leap Year of February cannot more than 28");
									flag = 1;
								}
							}
							else if(selectedMonth == 4 || selectedMonth == 6 || selectedMonth == 9 || selectedMonth == 11) {
								if(selectedMonth == 4) {
									if(selectedDay >= 31) {
										JOptionPane alert = new JOptionPane();
										alert.showMessageDialog(x, "Error! Day in April cannot be more than 31");
										flag = 1;
									}
								}
								else if(selectedMonth == 6) {
									if(selectedDay >= 31) {
										JOptionPane alert = new JOptionPane();
										alert.showMessageDialog(x, "Error! Day in June cannot be more than 31");
										flag = 1;}
								}
								else if(selectedMonth == 9) {
									if(selectedDay >= 31) {
										JOptionPane alert = new JOptionPane();
										alert.showMessageDialog(x, "Error! Day in September cannot be more than 31");
										flag = 1;}
								}
								else if(selectedMonth == 11) {
									if(selectedDay >= 31) {
										JOptionPane alert = new JOptionPane();
										alert.showMessageDialog(x, "Error! Day in November cannot be more than 31");
										flag = 1;}
								}
							}
							if(flag == 0) {
								vh.updateVoucher(id, discounts, dateCurr);
								JFrame z = new JFrame();
								z.setSize(500, 500);
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(z, "Update Voucher Success!");
								jf.dispose();
							}
						}
					}
					else {
						JFrame z = new JFrame();
						z.setSize(500, 500);
						JOptionPane alert = new JOptionPane();
						alert.showMessageDialog(z, "You cannot pick the Date that has been past from this time!");
						}
					}
				}
				else {
					JFrame z = new JFrame();
					z.setSize(500, 500);
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(z, "ID of Voucher not Found!");
					
				}
			}
		});
		jp.add(input,BorderLayout.CENTER);
		jp.add(submit,BorderLayout.SOUTH);
		jf.add(jp);
		jf.setSize(500,500);
		jf.show();
	}
	public void viewAllVoucher() {
		JFrame jf = new JFrame();
		JPanel jp = new JPanel(new BorderLayout());
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		jp.add(back,BorderLayout.NORTH);
		JPanel listVoucher = new JPanel(new GridLayout(vh.getAllVoucher().size(),0));
		listVoucher.setBorder(new EmptyBorder(10,10,10,10));
		for(int i = 0;i<vh.getAllVoucher().size();i++) {
			if(vh.getAllVoucher().get(i).getVoucherStatus().equalsIgnoreCase("active")) {
				JPanel voucher = new JPanel(new GridLayout(4,1));
				voucher.setBorder(BorderFactory.createLineBorder(Color.BLACK));
				JLabel id = new JLabel(Integer.toString(vh.getAllVoucher().get(i).getVoucherID()));
				JLabel valid_date = new JLabel(vh.getAllVoucher().get(i).getVoucherValidDate().toString());
				JLabel discount = new JLabel(Float.toString(vh.getAllVoucher().get(i).getVoucherDiscount()) + "%");
				JLabel status = new JLabel(vh.getAllVoucher().get(i).getVoucherStatus());
				JLabel id1 = new JLabel("Voucher ID: ");
				JLabel id2 = new JLabel("Voucher Discount: ");
				JLabel id7 = new JLabel("Voucher Valid Date: ");
				JLabel id8 = new JLabel("Voucher Status: ");
				voucher.add(id1);
				voucher.add(id);
				voucher.add(id2);
				voucher.add(discount);
				voucher.add(id7);
				voucher.add(valid_date);
				voucher.add(id8);
				voucher.add(status);
				listVoucher.add(voucher);
			}
		}
		JScrollPane jsp = new JScrollPane();
		jsp.setSize(400,400);
		jsp.setViewportView(listVoucher);
		jp.add(jsp,BorderLayout.CENTER);
		jf.add(jp);
		jf.setSize(500,500);
		jf.show();
	}
	public void deleteVoucher() {
		JFrame jf = new JFrame();
		JPanel jp = new JPanel(new BorderLayout());
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		jp.add(back,BorderLayout.NORTH);
		JPanel listVoucher = new JPanel(new GridLayout(vh.getAllVoucher().size(),1));
		listVoucher.setBorder(new EmptyBorder(10,10,10,10));
		JButton[] listButton = new JButton[vh.getAllVoucher().size()];
		for(int i = 0;i<vh.getAllVoucher().size();i++) {
			if(vh.getAllVoucher().get(i).getVoucherStatus().equalsIgnoreCase("active")) {
				JPanel voucher = new JPanel(new GridLayout(4,1));
				voucher.setBorder(BorderFactory.createLineBorder(Color.BLACK));
				JLabel id = new JLabel(Integer.toString(vh.getAllVoucher().get(i).getVoucherID()));
				JLabel valid_date = new JLabel(vh.getAllVoucher().get(i).getVoucherValidDate().toString());
				JLabel discount = new JLabel(Float.toString(vh.getAllVoucher().get(i).getVoucherDiscount()) + "%");
				JLabel status = new JLabel(vh.getAllVoucher().get(i).getVoucherStatus());
				JLabel id1 = new JLabel("Voucher ID: ");
				JLabel id2 = new JLabel("Voucher Discount: ");
				JLabel id7 = new JLabel("Voucher Valid Date: ");
				JLabel id8 = new JLabel("Voucher Status: ");
				voucher.add(id1);
				voucher.add(id);
				voucher.add(id2);
				voucher.add(discount);
				voucher.add(id7);
				voucher.add(valid_date);
				voucher.add(id8);
				voucher.add(status);
				listVoucher.add(voucher);
				listButton[i] = new JButton("Delete Voucher");
				listButton[i].setActionCommand(Integer.toString(i));
				listButton[i].addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						// TODO Auto-generated method stub
						int x = Integer.parseInt(arg0.getActionCommand());
						JFrame validation = new JFrame();
						JPanel panel = new JPanel(new GridLayout(0,2));
						JLabel label = new JLabel("Are you sure you want to remove this Voucher?");
						validation.add(label,BorderLayout.NORTH);
						JButton button = new JButton("Yes");
						button.setBackground(Color.RED);
						JButton button2 = new JButton("No");
						button.addActionListener(new ActionListener() {
							
							@Override
							public void actionPerformed(ActionEvent e) {
								// TODO Auto-generated method stub
								JFrame z = new JFrame();
								z.setSize(500, 500);
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(z, "You remove Voucher with VoucherID =  " + vh.getAllVoucher().get(x).getVoucherID() + "!");
								vh.deleteVoucher(vh.getAllVoucher().get(x).getVoucherID());
								validation.dispose();
								jf.dispose();
							}
						});
						panel.add(button);
						panel.add(button2);
						validation.add(panel);
						validation.setSize(400,400);
						validation.show();
					}
				});
				listVoucher.add(listButton[i]);
			}
		}
		JScrollPane jsp = new JScrollPane();
		jsp.setSize(400,400);
		jsp.setViewportView(listVoucher);
		jp.add(jsp,BorderLayout.CENTER);
		jf.add(jp);
		jf.setSize(500,500);
		jf.show();
	}
	public void insertVoucher() {
		JFrame frame = new JFrame();
		JPanel panel = new JPanel(new BorderLayout());
		frame.setSize(500,500);
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				frame.dispose();
			}
		});
		JPanel panelInput = new JPanel(new GridLayout(2,1));
		JLabel discount = new JLabel("Discount: ");
		panelInput.add(discount);
		JTextField discount_input = new JTextField(16);
		panelInput.add(discount_input);
		JLabel validDate = new JLabel("Valid Date: ");
		panelInput.add(validDate);
		JPanel panelDate = new JPanel(new GridLayout(0,3));
		addDay();
		addMonth();
		addYear();
		JComboBox<String> yearSelect = new JComboBox<String>(this.year);
		yearSelect.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				validateYear((String)yearSelect.getSelectedItem());
			}
		});
		JComboBox<String> monthSelect = new JComboBox<String>(this.month);
		monthSelect.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				addMonth2(monthSelect.getSelectedIndex());
			}
		});
		JComboBox<String> daySelect = new JComboBox<String>(this.day);
		daySelect.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setDay((String)daySelect.getSelectedItem());
			}
		});
		panelDate.add(yearSelect);
		panelDate.add(monthSelect);
		panelDate.add(daySelect);
		panelInput.add(panelDate);
		panel.add(back,BorderLayout.NORTH);
		panel.add(panelInput,BorderLayout.CENTER);
		JButton submit = new JButton("Enter");
		submit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				double discounts= 0;
				int flag = 0;
				try {
					discounts = Double.parseDouble(discount_input.getText());
					if(discounts > 100 || discounts < 1) {
						JFrame z = new JFrame();
						z.setSize(500, 500);
						JOptionPane alert = new JOptionPane();
						alert.showMessageDialog(z, "The input only can take 1 to 100!");
						flag = 1;
					}
				} catch (Exception e2) {
					// TODO: handle exception
					flag = 1;
					JFrame z = new JFrame();
					z.setSize(500, 500);
					JOptionPane alert = new JOptionPane();
					alert.showMessageDialog(z, "The discount input only can take number, it's not allowed characters in discount area!");
				}
				if(flag == 0) {
					Date dateNow = new Date(System.currentTimeMillis());
					Date dateCurr = new Date(selectedYear-1900, selectedMonth-1, selectedDay);
					JFrame x = new JFrame();
					x.setSize(500,500);
					if(dateCurr.after(dateNow)) {
						if(selectedYear == -1) {
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x, "Year must be choosen!");
						}
						else if(selectedMonth == -1) {
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x, "Month must be choosen!");
						}
						else if(selectedDay == -1){
							JOptionPane alert = new JOptionPane();
							alert.showMessageDialog(x, "Day must be choosen!");
						}
						else {
							flag = 0;
							if(selectedMonth == 2 && kabisat == 1) {
								if(selectedDay > 29) {
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Error! Day in Leap Year of February cannot more than 29");
									flag = 1;
								}
							}
							else if(selectedMonth == 2 && kabisat == 0) {
								if(selectedDay > 28) {
									JOptionPane alert = new JOptionPane();
									alert.showMessageDialog(x, "Error! Day in Non Leap Year of February cannot more than 28");
									flag = 1;
								}
							}
							else if(selectedMonth == 4 || selectedMonth == 6 || selectedMonth == 9 || selectedMonth == 11) {
								if(selectedMonth == 4) {
									if(selectedDay >= 31) {
										JOptionPane alert = new JOptionPane();
										alert.showMessageDialog(x, "Error! Day in April cannot be more than 31");
										flag = 1;
									}
								}
								else if(selectedMonth == 6) {
									if(selectedDay >= 31) {
										JOptionPane alert = new JOptionPane();
										alert.showMessageDialog(x, "Error! Day in June cannot be more than 31");
										flag = 1;}
								}
								else if(selectedMonth == 9) {
									if(selectedDay >= 31) {
										JOptionPane alert = new JOptionPane();
										alert.showMessageDialog(x, "Error! Day in September cannot be more than 31");
										flag = 1;}
								}
								else if(selectedMonth == 11) {
									if(selectedDay >= 31) {
										JOptionPane alert = new JOptionPane();
										alert.showMessageDialog(x, "Error! Day in November cannot be more than 31");
										flag = 1;}
								}
							}
							if(flag == 0) {
								vh.insertVoucher((float)discounts, dateCurr);	
								JFrame z = new JFrame();
								z.setSize(500, 500);
								JOptionPane alert = new JOptionPane();
								alert.showMessageDialog(z, "Insert Voucher Success!");
							}
						}
					}
					else {
						JFrame z = new JFrame();
						z.setSize(500, 500);
						JOptionPane alert = new JOptionPane();
						alert.showMessageDialog(z, "You cannot pick the Date that has been past from this time!");
					}
				}
			}
		});
		panel.add(submit,BorderLayout.SOUTH);
		frame.add(panel);
		frame.show();
	}
	public void menu(String name) {
		JFrame frame = new JFrame();
		JPanel panel = new JPanel(new GridLayout(6,0));
		JLabel title = new JLabel("Welcome " + name + "!");
		panel.add(title);
		JButton createButton = new JButton("Create Voucher");
		createButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insertVoucher();
			}
		});
		JButton viewButton = new JButton("View All Active Voucher");
		viewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				viewAllVoucher();
			}
		});
		JButton updateButton = new JButton("Update Voucher");
		updateButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				updateVoucher();
			}
		});
		JButton deleteButton = new JButton("Delete Voucher");
		deleteButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				deleteVoucher();
			}
		});
		panel.add(createButton);
		panel.add(viewButton);
		panel.add(updateButton);
		panel.add(deleteButton);
		JButton button = new JButton("Logout");
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				frame.dispose();
			}
		});
		panel.add(button);
		frame.add(panel);
		frame.setSize(500,500);
		frame.show();
	}
}
