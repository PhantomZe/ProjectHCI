import java.sql.*;
public class Employee {
	private int EmployeeID;
	private int roleID;
	private String EmployeeName;
	private String EmployeeUsername;
	private Date EmployeeDOB;
	private int EmployeeSalary;
	private String EmployeeStatus;
	private String EmployeePassword;
	public Employee(int EmployeeID, int roleID, String EmployeeName, String EmployeeUsername, Date EmployeeDOB, int EmployeeSalary, String status, String password) {
		this.EmployeeID = EmployeeID;
		this.roleID = roleID;
		this.EmployeeName = EmployeeName;
		this.EmployeeUsername = EmployeeUsername;
		this.EmployeeDOB = EmployeeDOB;
		this.EmployeeSalary = EmployeeSalary;
		this.EmployeeStatus = status;
		this.EmployeePassword = password;
	}
	public int getEmployeeID() {
		return EmployeeID;
	}
	public void setEmployeeID(int employeeID) {
		EmployeeID = employeeID;
	}
	public int getRoleID() {
		return roleID;
	}
	public void setRoleID(int roleID) {
		this.roleID = roleID;
	}
	public String getEmployeeName() {
		return EmployeeName;
	}
	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}
	public String getEmployeeUsername() {
		return EmployeeUsername;
	}
	public void setEmployeeUsername(String employeeUsername) {
		EmployeeUsername = employeeUsername;
	}
	public Date getEmployeeDOB() {
		return EmployeeDOB;
	}
	public void setEmployeeDOB(Date employeeDOB) {
		EmployeeDOB = employeeDOB;
	}
	public int getEmployeeSalary() {
		return EmployeeSalary;
	}
	public void setEmployeeSalary(int employeeSalary) {
		EmployeeSalary = employeeSalary;
	}
	public String getEmployeeStatus() {
		return EmployeeStatus;
	}
	public void setEmployeeStatus(String employeeStatus) {
		EmployeeStatus = employeeStatus;
	}
	public String getEmployeePassword() {
		return EmployeePassword;
	}
	public void setEmployeePassword(String employeePassword) {
		EmployeePassword = employeePassword;
	}
}
