import java.sql.Date;

public class Voucher {
	private int voucherID;
	private float voucherDiscount;
	private Date voucherValidDate;
	private String voucherStatus;
	public Voucher(int voucherID, float voucherDiscount, Date voucherValidDate, String voucherStatus) {
		// TODO Auto-generated constructor stub
		this.voucherID = voucherID;
		this.voucherDiscount = voucherDiscount;
		this.voucherValidDate = voucherValidDate;
		this.voucherStatus = voucherStatus;
	}
	public int getVoucherID() {
		return voucherID;
	}
	public void setVoucherID(int voucherID) {
		this.voucherID = voucherID;
	}
	public float getVoucherDiscount() {
		return voucherDiscount;
	}
	public void setVoucherDiscount(float voucherDiscount) {
		this.voucherDiscount = voucherDiscount;
	}
	public Date getVoucherValidDate() {
		return voucherValidDate;
	}
	public void setVoucherValidDate(Date voucherValidDate) {
		this.voucherValidDate = voucherValidDate;
	}
	public String getVoucherStatus() {
		return voucherStatus;
	}
	public void setVoucherStatus(String voucherStatus) {
		this.voucherStatus = voucherStatus;
	}
	public void updateVoucher(float voucherDiscount, Date voucherValidDate) {
		this.voucherDiscount = voucherDiscount;
		this.voucherValidDate = voucherValidDate;
	}
}
